import { useLanguage } from '@/context/LanguageContext';

const channels = [
  {
    icon: '📞',
    title: 'omni.voice_title',
    desc: 'omni.voice_desc',
  },
  {
    icon: '💬',
    title: 'omni.chat_title',
    desc: 'omni.chat_desc',
  },
  {
    icon: '📱',
    title: 'omni.sms_title',
    desc: 'omni.sms_desc',
  },
  {
    icon: '🔌',
    title: 'omni.api_title',
    desc: 'omni.api_desc',
  },
];

export default function Omnichannel() {
  const { t } = useLanguage();

  return (
    <section className="py-24 bg-[#0f0f17] border-y border-[rgba(255,255,255,0.06)]" id="omni">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="section-label mb-3">{t('omni.label')}</div>
          <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight">
            {t('omni.title')}
          </h2>
        </div>

        {/* Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {channels.map((channel, i) => (
            <div
              key={i}
              className="bg-[#12121c] border border-[rgba(255,255,255,0.06)] rounded-xl p-7 text-center transition-all hover:-translate-y-1 hover:border-[rgba(255,255,255,0.1)]"
            >
              <div className="w-12 h-12 rounded-lg bg-[rgba(124,92,252,0.12)] flex items-center justify-center text-[22px] mx-auto mb-4">
                {channel.icon}
              </div>
              <h3 className="font-['Instrument_Sans',sans-serif] text-base font-bold mb-2">
                {t(channel.title)}
              </h3>
              <p className="text-xs text-[#6e6e85] leading-relaxed">
                {t(channel.desc)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
