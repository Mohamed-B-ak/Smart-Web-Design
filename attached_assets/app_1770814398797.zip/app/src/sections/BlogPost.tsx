import { useLanguage } from '@/context/LanguageContext';
import type { BlogPost as BlogPostType } from '@/data/blog';
import { ArrowRight, ArrowLeft, Calendar, Clock } from 'lucide-react';

interface BlogPostProps {
  post: BlogPostType;
  onBack: () => void;
}

export default function BlogPost({ post, onBack }: BlogPostProps) {
  const { lang } = useLanguage();

  const content = lang === 'en' ? post.content : post.contentAr;

  return (
    <article className="py-24 min-h-screen">
      <div className="max-w-[800px] mx-auto px-6">
        {/* Back Button */}
        <button
          onClick={onBack}
          className="inline-flex items-center gap-2 text-[13px] text-[#a1a1b5] hover:text-[#f5f5f7] mb-8 transition-colors"
        >
          {lang === 'en' ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
          {lang === 'en' ? 'Back to Blog' : 'العودة إلى المدونة'}
        </button>

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-[10px] font-semibold uppercase tracking-wider text-[#9b8afb] bg-[rgba(124,92,252,0.08)] px-2 py-1 rounded-full">
              {lang === 'en' ? post.category : post.categoryAr}
            </span>
            <span className="flex items-center gap-1 text-[11px] text-[#6e6e85]">
              <Clock className="w-3 h-3" />
              {post.readTime}
            </span>
          </div>

          <h1 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,4vw,42px)] font-bold leading-tight tracking-tight mb-4">
            {lang === 'en' ? post.title : post.titleAr}
          </h1>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full gradient-bg flex items-center justify-center text-sm font-bold text-white">
                {post.author.charAt(0)}
              </div>
              <span className="text-sm text-[#a1a1b5]">{post.author}</span>
            </div>
            <span className="text-[#6e6e85]">•</span>
            <span className="flex items-center gap-1 text-sm text-[#6e6e85]">
              <Calendar className="w-3.5 h-3.5" />
              {new Date(post.date).toLocaleDateString(lang === 'en' ? 'en-US' : 'ar-SA', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </span>
          </div>
        </div>

        {/* Featured Image */}
        <div className="aspect-video bg-gradient-to-br from-[#14141e] to-[#1a1a2e] rounded-xl flex items-center justify-center mb-8">
          <div className="w-20 h-20 rounded-full bg-[rgba(124,92,252,0.12)] flex items-center justify-center text-4xl">
            📝
          </div>
        </div>

        {/* Content */}
        <div 
          className="prose prose-invert prose-lg max-w-none"
          dangerouslySetInnerHTML={{ __html: content }}
        />

        {/* Share */}
        <div className="mt-12 pt-8 border-t border-[rgba(255,255,255,0.06)]">
          <p className="text-sm text-[#6e6e85] mb-3">
            {lang === 'en' ? 'Share this article:' : 'شارك هذا المقال:'}
          </p>
          <div className="flex gap-2">
            {['𝕏', 'in', '📧'].map((icon, i) => (
              <button
                key={i}
                className="w-9 h-9 rounded-full bg-[rgba(255,255,255,0.04)] flex items-center justify-center text-sm text-[#6e6e85] hover:bg-[#7c5cfc] hover:text-white transition-all"
              >
                {icon}
              </button>
            ))}
          </div>
        </div>
      </div>
    </article>
  );
}
