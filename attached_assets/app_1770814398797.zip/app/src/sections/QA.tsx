import { useLanguage } from '@/context/LanguageContext';

const qaCards = [
  {
    icon: '🧪',
    title: 'qa.test_title',
    desc: 'qa.test_desc',
  },
  {
    icon: '🔄',
    title: 'qa.cont_title',
    desc: 'qa.cont_desc',
  },
  {
    icon: '📊',
    title: 'qa.perf_title',
    desc: 'qa.perf_desc',
  },
];

export default function QA() {
  const { t } = useLanguage();

  return (
    <section className="py-24" id="quality">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="section-label mb-3">{t('qa.label')}</div>
          <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight">
            {t('qa.title')}
          </h2>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-5">
          {qaCards.map((card, i) => (
            <div
              key={i}
              className="bg-[#12121c] border border-[rgba(255,255,255,0.06)] rounded-xl p-7 transition-all hover:-translate-y-1 hover:border-[rgba(255,255,255,0.1)]"
            >
              <div className="w-11 h-11 rounded-lg bg-[rgba(124,92,252,0.12)] flex items-center justify-center text-xl mb-4">
                {card.icon}
              </div>
              <h4 className="text-base font-bold mb-1.5">{t(card.title)}</h4>
              <p className="text-[13px] text-[#a1a1b5] leading-relaxed">
                {t(card.desc)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
