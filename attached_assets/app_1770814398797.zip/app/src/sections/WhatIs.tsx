import { useLanguage } from '@/context/LanguageContext';
import { Check, X } from 'lucide-react';

const features = [
  'what.feat1',
  'what.feat2',
  'what.feat3',
  'what.feat4',
];

export default function WhatIs() {
  const { t } = useLanguage();

  const cards = [
    {
      tag: 'what.other',
      title: 'what.ivr',
      desc: 'what.ivr_desc',
      checks: [false, false, false, false],
    },
    {
      tag: 'what.other',
      title: 'what.iva',
      desc: 'what.iva_desc',
      checks: [false, true, false, false],
    },
    {
      tag: 'what.our',
      title: 'what.gen3',
      desc: 'what.gen3_desc',
      checks: [true, true, true, true],
      featured: true,
    },
  ];

  return (
    <section className="py-24 bg-[#0f0f17] border-y border-[rgba(255,255,255,0.06)]" id="what">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="section-label mb-3">{t('what.label')}</div>
          <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight mb-4">
            {t('what.title')}
          </h2>
          <p className="text-[17px] text-[#a1a1b5] max-w-[560px] mx-auto leading-relaxed">
            {t('what.subtitle')}
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-5">
          {cards.map((card, i) => (
            <div
              key={i}
              className={`relative bg-[#12121c] border rounded-xl p-7 transition-all hover:-translate-y-1 ${
                card.featured
                  ? 'border-[#7c5cfc] bg-gradient-to-br from-[rgba(124,92,252,0.06)] to-[rgba(124,92,252,0.01)]'
                  : 'border-[rgba(255,255,255,0.06)] hover:border-[rgba(255,255,255,0.1)]'
              }`}
            >
              {card.featured && (
                <div className="absolute -top-3 left-5 bg-gradient-to-r from-[#7c5cfc] to-[#9b8afb] text-white text-[10px] font-bold uppercase tracking-wider px-3.5 py-1 rounded-full">
                  {t('what.our')}
                </div>
              )}
              <div className={`inline-block text-[10px] font-semibold uppercase tracking-wider text-[#6e6e85] px-2.5 py-1 bg-[rgba(255,255,255,0.04)] rounded-full mb-3.5`}>
                {t(card.tag)}
              </div>
              <h3 className="font-['Instrument_Sans',sans-serif] text-xl font-bold mb-1.5">
                {t(card.title)}
              </h3>
              <p className="text-[13px] text-[#6e6e85] mb-5 leading-relaxed">
                {t(card.desc)}
              </p>
              <div className="flex flex-col gap-2.5">
                {features.map((feat, j) => (
                  <div key={j} className="flex items-center gap-2.5 text-[13px] text-[#a1a1b5]">
                    <span className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                      card.checks[j] 
                        ? 'bg-[rgba(0,214,143,0.12)] text-[#00d68f]' 
                        : 'bg-[rgba(255,107,107,0.1)] text-[#ff6b6b]'
                    }`}>
                      {card.checks[j] ? <Check className="w-3 h-3" /> : <X className="w-3 h-3" />}
                    </span>
                    {t(feat)}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
