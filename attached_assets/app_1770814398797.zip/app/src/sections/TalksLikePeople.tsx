import { useLanguage } from '@/context/LanguageContext';

export default function TalksLikePeople() {
  const { t } = useLanguage();

  return (
    <section className="py-20 relative overflow-hidden">
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="flex items-center justify-center rounded-2xl bg-gradient-to-br from-[rgba(124,92,252,0.06)] to-[rgba(110,168,254,0.04)] border border-[rgba(255,255,255,0.06)] min-h-[320px] relative overflow-hidden">
          <div className="text-center relative z-10">
            <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(32px,5vw,56px)] font-extrabold tracking-tight mb-2">
              {t('talks.title')}{' '}
              <span className="gradient-text">{t('talks.title_span')}</span>
            </h2>
            <p className="text-[17px] text-[#a1a1b5]">
              {t('talks.subtitle')}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
