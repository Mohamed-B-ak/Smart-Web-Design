export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  titleAr: string;
  excerpt: string;
  excerptAr: string;
  content: string;
  contentAr: string;
  author: string;
  date: string;
  category: string;
  categoryAr: string;
  image: string;
  readTime: string;
}

export const blogPosts: BlogPost[] = [
  {
    id: '1',
    slug: 'future-of-ai-voice-agents',
    title: 'The Future of AI Voice Agents in Healthcare',
    titleAr: 'مستقبل وكلاء الصوت الذكي في الرعاية الصحية',
    excerpt: 'Discover how AI voice agents are transforming patient care and medical facility operations across the Middle East.',
    excerptAr: 'اكتشف كيف يحول وكلاء الصوت الذكي رعاية المرضى وعمليات المنشآت الطبية في جميع أنحاء الشرق الأوسط.',
    content: `
      <p>AI voice agents are revolutionizing the healthcare industry by automating routine tasks and improving patient experiences. From appointment scheduling to post-call follow-ups, these intelligent systems are transforming how medical facilities operate.</p>
      
      <h2>Key Benefits for Healthcare</h2>
      <p>Healthcare providers across the Middle East are adopting AI voice agents to:</p>
      <ul>
        <li>Reduce wait times for patients</li>
        <li>Automate appointment scheduling and reminders</li>
        <li>Handle prescription refill requests</li>
        <li>Provide 24/7 patient support</li>
        <li>Free up staff for critical care tasks</li>
      </ul>

      <h2>The Sondos AI Advantage</h2>
      <p>Built specifically for the MENA region, Sondos AI understands Arabic dialects and healthcare terminology. Our platform delivers human-like conversations with just 600ms latency, ensuring natural interactions that patients trust.</p>

      <h2>Looking Ahead</h2>
      <p>As AI technology continues to evolve, we expect voice agents to handle increasingly complex healthcare scenarios while maintaining the empathy and understanding that patients deserve.</p>
    `,
    contentAr: `
      <p>يُحدث وكلاء الصوت الذكي ثورة في صناعة الرعاية الصحية من خلال أتمتة المهام الروتينية وتحسين تجارب المرضى. من جدولة المواعيد إلى المتابعات بعد المكالمة، تحول هذه الأنظمة الذكية طريقة عمل المنشآت الطبية.</p>
      
      <h2>الفوائد الرئيسية للرعاية الصحية</h2>
      <p>يتبنى مقدمو الرعاية الصحية في جميع أنحاء الشرق الأوسط وكلاء الصوت الذكي من أجل:</p>
      <ul>
        <li>تقليل أوقات الانتظار للمرضى</li>
        <li>أتمتة جدولة المواعيد والتذكيرات</li>
        <li>التعامل مع طلبات إعادة تعبئة الوصفات الطبية</li>
        <li>توفير دعم على مدار الساعة للمرضى</li>
        <li>تحرير الموظفين لمهام الرعاية الحرجة</li>
      </ul>

      <h2>ميزة سندس AI</h2>
      <p>تم بناء سندس AI خصيصاً لمنطقة الشرق الأوسط وشمال أفريقيا، ويفهم اللهجات العربية ومصطلحات الرعاية الصحية. تقدم منصتنا محادثات شبيهة بالبشر مع زمن استجابة 600 مللي ثانية فقط، مما يضمن تفاعلات طبيعية يثق بها المرضى.</p>

      <h2>النظرة إلى المستقبل</h2>
      <p>مع استمرار تطور تقنية الذكاء الاصطناعي، نتوقع أن يتعامل وكلاء الصوت مع سيناريوهات رعاية صحية متزايدة التعقيد مع الحفاظ على التعاطف والتفهم الذي يستحقه المرضى.</p>
    `,
    author: 'Dr. Ahmed Khalid',
    date: '2026-01-15',
    category: 'Healthcare',
    categoryAr: 'الرعاية الصحية',
    image: '/blog/healthcare-ai.jpg',
    readTime: '5 min',
  },
  {
    id: '2',
    slug: 'understanding-latency-voice-ai',
    title: 'Understanding Latency in Voice AI: Why Every Millisecond Matters',
    titleAr: 'فهم زمن الاستجابة في الصوت الذكي: لماذا كل مللي ثانية مهمة',
    excerpt: 'Learn why low latency is crucial for natural conversations and how Sondos AI achieves industry-leading response times.',
    excerptAr: 'تعرف على لماذا زمن الاستجابة المنخفض مهم للمحادثات الطبيعية وكيف تحقق سندس AI أوقات استجابة رائدة في الصناعة.',
    content: `
      <p>When it comes to voice AI, latency is everything. The time between when a user speaks and when the AI responds can make or break the conversation experience.</p>

      <h2>What is Latency?</h2>
      <p>Latency in voice AI refers to the total time it takes for the system to process speech, generate a response, and deliver it back to the user. This includes:</p>
      <ul>
        <li>Speech-to-text conversion</li>
        <li>Language model processing</li>
        <li>Text-to-speech generation</li>
        <li>Network transmission</li>
      </ul>

      <h2>The 600ms Benchmark</h2>
      <p>At Sondos AI, we've achieved an industry-leading ~600ms latency. This means conversations feel natural and fluid, without the awkward pauses that plague other voice AI systems.</p>

      <h2>How We Do It</h2>
      <p>Our proprietary voice AI orchestration uses advanced techniques like streaming processing, optimized model inference, and edge deployment to minimize response times without sacrificing quality.</p>
    `,
    contentAr: `
      <p>عندما يتعلق الأمر بالصوت الذكي، زمن الاستجابة هو كل شيء. الوقت بينما يتحدث المستخدم ويرد الذكاء الاصطناعي يمكن أن يصنع أو يكسر تجربة المحادثة.</p>

      <h2>ما هو زمن الاستجابة؟</h2>
      <p>يشير زمن الاستجابة في الصوت الذكي إلى الوقت الإجمالي الذي يستغرقه النظام لمعالجة الكلام وإنشاء رد وإيصاله مرة أخرى إلى المستخدم. وهذا يشمل:</p>
      <ul>
        <li>تحويل الكلام إلى نص</li>
        <li>معالجة نموذج اللغة</li>
        <li>إنشاء تحويل النص إلى كلام</li>
        <li>نقل الشبكة</li>
      </ul>

      <h2>معيار 600 مللي ثانية</h2>
      <p>في سندس AI، حققنا زمن استجابة رائد في الصناعة يبلغ ~600 مللي ثانية. وهذا يعني أن المحادثات تبدو طبيعية وسلسة، بدون التوقفات المحرجة التي تعاني منها أنظمة الصوت الذكي الأخرى.</p>

      <h2>كيف نفعل ذلك</h2>
      <p>يستخدم تنسيق الصوت الذكي الخاص بنا تقنيات متقدمة مثل المعالجة المتدفقة والاستدلال المحسّن للنماذج والنشر على الحافة لتقليل أوقات الاستجابة دون التضحية بالجودة.</p>
    `,
    author: 'Sarah Al-Rashid',
    date: '2026-01-10',
    category: 'Technology',
    categoryAr: 'تقنية',
    image: '/blog/latency.jpg',
    readTime: '4 min',
  },
  {
    id: '3',
    slug: 'arabic-voice-ai-challenges',
    title: 'Building Arabic-First Voice AI: Challenges and Solutions',
    titleAr: 'بناء صوت ذكي بالعربية أولاً: التحديات والحلول',
    excerpt: 'Explore the unique challenges of developing voice AI for Arabic speakers and how Sondos AI addresses them.',
    excerptAr: 'استكشف التحديات الفريدة لتطوير الصوت الذكي للناطقين بالعربية وكيف تعالجها سندس AI.',
    content: `
      <p>Building voice AI for Arabic presents unique challenges that many global platforms fail to address. From dialect variations to grammatical complexity, creating a truly Arabic-first experience requires deep understanding and specialized approaches.</p>

      <h2>The Dialect Challenge</h2>
      <p>Arabic is not a single language but a family of dialects spanning from Morocco to the Gulf. Our AI is trained on diverse Arabic datasets to understand:</p>
      <ul>
        <li>Khaliji (Gulf) dialects</li>
        <li>Egyptian Arabic</li>
        <li>Levantine dialects</li>
        <li>Modern Standard Arabic</li>
      </ul>

      <h2>Code-Switching</h2>
      <p>Arabic speakers frequently mix Arabic with English and other languages. Our models handle code-switching seamlessly, understanding context regardless of language mixing.</p>

      <h2>Cultural Sensitivity</h2>
      <p>Beyond language, our AI understands cultural nuances, greeting patterns, and communication styles specific to the Arab world.</p>
    `,
    contentAr: `
      <p>يقدم بناء الصوت الذكي للعربية تحديات فريدة تفشل العديد من المنصات العالمية في معالجتها. من اختلافات اللهجات إلى التعقيد النحوي، يتطلب إنشاء تجربة حقيقية بالعربية أولاً فهماً عميقاً ومناهج متخصصة.</p>

      <h2>تحدي اللهجة</h2>
      <p>العربية ليست لغة واحدة بل عائلة من اللهجات تمتد من المغرب إلى الخليج. تم تدريب ذكاء الاصطناعي الخاص بنا على مجموعات بيانات عربية متنوعة لفهم:</p>
      <ul>
        <li>لهجات الخليج</li>
        <li>اللهجة المصرية</li>
        <li>لهجات الشام</li>
        <li>الفصحى الحديثة</li>
      </ul>

      <h2>التبديل بين اللغات</h2>
      <p>ينتقل الناطقون بالعربية بشكل متكرر بين العربية والإنجليزية ولغات أخرى. تعالج نماذجنا التبديل بين اللغات بسلاسة، وفهم السياق بغض النظر عن خلط اللغات.</p>

      <h2>الحساسية الثقافية</h2>
      <p>بعد اللغة، يفهم ذكاء الاصطناعي لدينا الفروق الثقافية وأنماط التحية وأنماط التواصل الخاصة بالعالم العربي.</p>
    `,
    author: 'Mohammed Al-Farsi',
    date: '2026-01-05',
    category: 'AI Research',
    categoryAr: 'بحث الذكاء الاصطناعي',
    image: '/blog/arabic-ai.jpg',
    readTime: '6 min',
  },
];

export function getBlogPostBySlug(slug: string): BlogPost | undefined {
  return blogPosts.find(post => post.slug === slug);
}

export function getAllBlogPosts(): BlogPost[] {
  return blogPosts;
}
