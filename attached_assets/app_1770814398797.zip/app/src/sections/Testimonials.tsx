import { useLanguage } from '@/context/LanguageContext';
import { Play, ArrowRight, ArrowLeft } from 'lucide-react';

const testimonials = [
  {
    quote: 'test.quote1',
    author: 'test.author1',
    role: 'test.role1',
    initials: 'د.م',
  },
  {
    quote: 'test.quote2',
    author: 'test.author2',
    role: 'test.role2',
    initials: 'س.ع',
  },
  {
    quote: 'test.quote3',
    author: 'test.author3',
    role: 'test.role3',
    initials: 'أ.خ',
  },
];

export default function Testimonials() {
  const { lang, t } = useLanguage();

  return (
    <section className="py-24 bg-[#0f0f17] border-y border-[rgba(255,255,255,0.06)]" id="testimonials">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="section-label mb-3">{t('test.label')}</div>
          <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight mb-4">
            {t('test.title')}
          </h2>
          <p className="text-[17px] text-[#a1a1b5] max-w-[560px] mx-auto leading-relaxed">
            {t('test.subtitle')}
          </p>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-5">
          {testimonials.map((test, i) => (
            <div
              key={i}
              className="bg-[#12121c] border border-[rgba(255,255,255,0.06)] rounded-xl overflow-hidden transition-all hover:-translate-y-1 hover:border-[rgba(255,255,255,0.1)]"
            >
              {/* Video Placeholder */}
              <div className="relative aspect-video bg-gradient-to-br from-[#14141e] to-[#1a1a2e] flex items-center justify-center">
                <button className="w-13 h-13 rounded-full bg-[rgba(255,255,255,0.1)] backdrop-blur-lg border-2 border-[rgba(255,255,255,0.2)] flex items-center justify-center hover:scale-110 transition-transform">
                  <Play className="w-5 h-5 fill-white text-white ml-0.5" />
                </button>
              </div>

              {/* Content */}
              <div className="p-6">
                <p className="text-[14px] text-[#a1a1b5] leading-relaxed mb-5 italic relative pl-4 border-l-2 border-[#7c5cfc]">
                  {t(test.quote)}
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full gradient-bg flex items-center justify-center font-bold text-sm text-white">
                    {test.initials}
                  </div>
                  <div>
                    <h5 className="text-[13px] font-semibold">{t(test.author)}</h5>
                    <p className="text-[11px] text-[#6e6e85]">{t(test.role)}</p>
                  </div>
                </div>
                <a 
                  href="#" 
                  className="inline-flex items-center gap-1 text-xs font-semibold text-[#9b8afb] mt-3 hover:underline"
                >
                  {t('test.read_case')}
                  {lang === 'en' ? <ArrowRight className="w-3 h-3" /> : <ArrowLeft className="w-3 h-3" />}
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
