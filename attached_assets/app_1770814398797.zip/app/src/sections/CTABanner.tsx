import { useLanguage } from '@/context/LanguageContext';

export default function CTABanner() {
  const { t } = useLanguage();

  return (
    <section className="py-24">
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="relative rounded-2xl bg-gradient-to-br from-[#1a1040] via-[#0d0d2a] to-[#0a1628] border border-[rgba(124,92,252,0.15)] px-10 py-20 text-center overflow-hidden">
          {/* Glow */}
          <div 
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px]"
            style={{
              background: 'radial-gradient(circle, rgba(124,92,252,.1) 0%, transparent 60%)'
            }}
          />
          
          {/* Content */}
          <div className="relative z-10">
            <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,4vw,44px)] font-bold tracking-tight mb-3">
              {t('cta.title')}
            </h2>
            <p className="text-[17px] text-[#a1a1b5] mb-8">
              {t('cta.subtitle')}
            </p>
            <div className="flex items-center justify-center gap-3.5 flex-wrap">
              <a 
                href="#" 
                className="inline-flex items-center gap-2 px-8 py-3.5 text-[15px] font-semibold text-white gradient-bg glow rounded-full hover:-translate-y-0.5 hover:shadow-[0_8px_30px_rgba(124,92,252,0.25)] transition-all"
              >
                {t('cta.try')}
              </a>
              <a 
                href="#" 
                className="inline-flex items-center gap-2 px-8 py-3.5 text-[15px] font-semibold text-[#f5f5f7] border border-[rgba(255,255,255,0.1)] rounded-full hover:bg-[rgba(255,255,255,0.05)] hover:border-[rgba(255,255,255,0.15)] transition-all"
              >
                {t('cta.contact')}
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
