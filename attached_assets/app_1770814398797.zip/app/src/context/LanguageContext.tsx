import React, { createContext, useContext, useState, useEffect } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navigation
    'nav.product': 'Product',
    'nav.pricing': 'Pricing',
    'nav.for_business': 'For Business',
    'nav.for_developers': 'For Developers',
    'nav.resources': 'Resources',
    'nav.company': 'Company',
    'nav.login': 'Login',
    'nav.contact_sales': 'Contact Sales',
    'nav.try_free': 'Try For Free',
    
    // Product dropdown
    'nav.call_transfer': 'Call Transfer',
    'nav.call_transfer_desc': 'Seamlessly transfer calls',
    'nav.book_appointments': 'Book Appointments',
    'nav.book_appointments_desc': 'Schedule automatically',
    'nav.knowledge_base': 'Knowledge Base',
    'nav.knowledge_base_desc': 'AI-powered knowledge',
    'nav.post_call': 'Post Call Analysis',
    'nav.post_call_desc': 'Detailed call insights',
    'nav.batch_call': 'Batch Call',
    'nav.batch_call_desc': 'Run large campaigns',
    'nav.verified': 'Verified Numbers',
    'nav.verified_desc': 'Trusted caller ID',
    
    // Business dropdown
    'nav.healthcare': 'Healthcare',
    'nav.healthcare_desc': 'Medical facilities',
    'nav.financial': 'Financial Services',
    'nav.financial_desc': 'Banks & finance',
    'nav.insurance': 'Insurance',
    'nav.insurance_desc': 'Claims management',
    'nav.logistics': 'Logistics',
    'nav.logistics_desc': 'Supply chain',
    
    // Hero
    'hero.badge': '#1 AI Voice Agent Platform for Automating Calls',
    'hero.title': 'Meet Your AI Call Center',
    'hero.title_span': 'From The Future',
    'hero.subtitle': 'Build, deploy, and manage next-generation AI voice agents that sound human, execute tasks, and scale effortlessly.',
    'hero.cta_demo': 'Try Our Live Demo',
    'hero.cta_sales': 'Contact Sales',
    
    // Dashboard
    'dash.dashboard': 'Dashboard',
    'dash.agents': 'Agents',
    'dash.history': 'Call History',
    'dash.knowledge': 'Knowledge Base',
    'dash.analytics': 'Analytics',
    'dash.campaigns': 'Campaigns',
    'dash.settings': 'Settings',
    'dash.total_calls': 'Total Calls Today',
    'dash.resolution': 'Resolution Rate',
    'dash.duration': 'Avg Call Duration',
    'dash.chart_title': 'Call Volume — Last 14 Days',
    
    // Logos
    'logos.trusted': 'TRUSTED BY LEADING COMPANIES',
    
    // Banner
    'banner.scale': 'Built',
    'banner.scale_span': 'to Scale.',
    
    // What is
    'what.label': 'Overview',
    'what.title': 'What is Sondos AI?',
    'what.subtitle': 'LLM-based, humanlike, voice-first conversational AI platform',
    'what.other': 'Other Solution',
    'what.our': 'Our Solution',
    'what.ivr': 'IVR Voice Agent',
    'what.ivr_desc': 'Primarily used for call routing through pre-defined, touch-tone menu options',
    'what.iva': 'IVA Voice Agent',
    'what.iva_desc': 'Powered by NLP and Intent Mapping',
    'what.gen3': '3rd Gen Voice AI',
    'what.gen3_desc': 'Powered by LLMs',
    'what.feat1': 'Natural, Human-Like Conversations',
    'what.feat2': 'Fast Setup With Minimal Configuration',
    'what.feat3': 'Handles Edge Cases And Unexpected Inputs',
    'what.feat4': 'Supports Complex, Multi-Turn Calls',
    
    // Demo
    'demo.label': 'Live Demo',
    'demo.title': 'Try Our Live Demo',
    'demo.subtitle': 'Receive a live call from our agent and discover how our AI caller transforms customer conversations.',
    'demo.step1_title': 'Select the type of call',
    'demo.step1_desc': 'Choose from receptionist, appointment setter, or customer service',
    'demo.step2_title': 'Enter your information',
    'demo.step2_desc': 'Provide your phone number and details',
    'demo.step3_title': 'Get a call',
    'demo.step3_desc': 'Our AI agent will call you within seconds',
    'demo.form_title': 'Select the type of call you want to receive',
    'demo.form_subtitle': 'Choose an agent type then enter your details',
    'demo.receptionist': 'Receptionist',
    'demo.appointment': 'Appointment Setter',
    'demo.lead': 'Lead Qualification',
    'demo.customer': 'Customer Service',
    'demo.debt': 'Debt Collection',
    'demo.survey': 'Survey',
    'demo.industry': 'Industry',
    'demo.healthcare': 'Healthcare',
    'demo.financial': 'Financial Services',
    'demo.insurance': 'Insurance',
    'demo.realestate': 'Real Estate',
    'demo.name': 'Name',
    'demo.name_ph': 'Enter name',
    'demo.phone': 'Phone Number',
    'demo.email': 'Email',
    'demo.submit': 'Get a call',
    
    // Testimonials
    'test.label': 'Proven Impact, Real Conversations',
    'test.title': 'Proven Impact, Real Conversations',
    'test.subtitle': 'Discover how businesses use our AI voice agents to streamline operations and scale effortlessly.',
    'test.quote1': "We've increased scheduling efficiency by 38%, and filled underutilized provider capacity, allowing our team to focus on meaningful patient care.",
    'test.author1': 'Dr. Mohammed',
    'test.role1': 'COO, Medical Group',
    'test.quote2': 'The AI answers calls in seconds, handles urgent support at scale, cuts support costs by over 50%, and significantly improves our margins.',
    'test.author2': 'Sarah Al-Rashid',
    'test.role2': 'CEO, HealthBridge',
    'test.quote3': 'We now handle 100% of inbound calls with only a 30% transfer rate, scaling effortlessly and collecting ~$280,000 per month without sacrificing patient trust.',
    'test.author3': 'Ahmed Khalid',
    'test.role3': 'CIO, National Medical',
    'test.read_case': 'Read Case Study',
    
    // Talks Like People
    'talks.title': 'Talks Like',
    'talks.title_span': 'People',
    'talks.subtitle': 'Indistinguishable from human conversation',
    
    // Highlights
    'hl.label': 'Highlights',
    'hl.title': 'Human-Standard AI Voice Agent, Out of the Box',
    'hl.subtitle': 'Proprietary Voice AI Orchestration Delivering Human-Quality, Low-Latency Phone Conversations At Scale',
    'hl.latency_title': 'Lowest Latency',
    'hl.latency_desc': 'Independent benchmarks confirm our platform as the leader in responsiveness. With ~600ms latency, conversations stay smooth and fluent.',
    'hl.voice_title': 'Ultra Realistic Voice',
    'hl.voice_desc': 'Built from real performance data and refined through human-guided training.',
    'hl.turn_title': 'Turn Taking',
    'hl.turn_desc': 'Proprietary turn taking model that knows when to stop, when to listen.',
    'hl.badge': '~600ms Latency',
    
    // Features
    'feat.label': 'Highlights',
    'feat.title': 'Effortless to Use, Highly Configurable AI Phone Agent Platform',
    'feat.subtitle': 'Handle everything from routine requests to complex edge cases. Launch in weeks, not months.',
    'feat.agentic_title': 'Highly Configurable Agentic Framework',
    'feat.agentic_desc': 'Design reliable conversational call flows with a drag-and-drop agentic framework, built-in guardrails, and full control over agent behavior.',
    'feat.agentic_b1': 'Visual drag-and-drop flow builder',
    'feat.agentic_b2': 'Built-in safety guardrails',
    'feat.agentic_b3': 'Full control over agent behavior',
    'feat.func_title': 'Real-Time Function Calling with Preset Functions',
    'feat.func_desc': 'Add built-in or custom functions directly into call flows, enabling agents to book appointments, process payments, and transfer calls in real time.',
    'feat.func_b1': 'Appointment booking APIs',
    'feat.func_b2': 'CRM & EHR integrations',
    'feat.func_b3': 'Custom webhook triggers',
    'feat.rag_title': 'Streaming RAG for Knowledge and Auto Sync',
    'feat.rag_desc': 'Ensure accurate, real-time answers in every call, backed by a knowledge base that automatically syncs with your latest website content.',
    'feat.rag_b1': 'Auto-sync from websites',
    'feat.rag_b2': 'PDF & document ingestion',
    'feat.rag_b3': 'Multi-language support',
    
    // QA
    'qa.label': 'Highlights',
    'qa.title': 'Consistently High Quality in Every AI Call, Continuously Improving',
    'qa.test_title': 'Comprehensive Agent Testing',
    'qa.test_desc': 'Test agents across real-world scenarios before launch, validating behavior, accuracy, and reliability at scale.',
    'qa.cont_title': 'Continuous QA',
    'qa.cont_desc': 'Review past calls to surface failure patterns and actionable insights that continuously improve agent performance.',
    'qa.perf_title': 'Performance Analytics Dashboard',
    'qa.perf_desc': 'Design custom charts and dashboards to analyze call outcomes, agent performance, and business impact.',
    
    // Omni
    'omni.label': 'Integrations',
    'omni.title': 'True Omni-Channel Communication',
    'omni.voice_title': 'Voice Call',
    'omni.voice_desc': 'Deliver natural, human-like phone conversations at scale.',
    'omni.chat_title': 'Chat',
    'omni.chat_desc': 'Deploy AI-powered conversations across web and in-app chat.',
    'omni.sms_title': 'SMS',
    'omni.sms_desc': 'Engage customers through reliable text messaging workflows.',
    'omni.api_title': 'API',
    'omni.api_desc': 'Build custom communication experiences through a flexible API.',
    
    // Telephony
    'tel.label': 'Highlights',
    'tel.title': 'A Telephony Stack Optimized For Reach, Reliability, And Results',
    'tel.branded_title': 'Display Branded Call ID',
    'tel.branded_desc': 'Enable Branded Call feature to unlock new levels of customer trust for outbound operations.',
    'tel.sip_title': 'Using SIP Trunking',
    'tel.sip_desc': 'Use your existing phone numbers or VOIP providers. Connect to any telephony using SIP Trunking.',
    'tel.batch_title': 'Batch Calling',
    'tel.batch_desc': 'Run batch call campaigns without concurrency limits, with detailed conversion tracking.',
    'tel.verified_title': 'Verified Phone Numbers',
    'tel.verified_desc': 'Build trust with verified phone numbers that prevent your calls being labeled as spam.',
    
    // Security
    'sec.label': 'Compliance and Security',
    'sec.title': 'Enterprise-Grade Security and Reliability',
    'sec.subtitle': 'From data protection to uptime, we deliver enterprise-grade security required to run voice AI at production scale.',
    'sec.comp': 'Compliance & Security',
    'sec.comp_desc': 'HIPAA, SOC2 Type II, GDPR compliant',
    'sec.sso': 'SSO',
    'sec.sso_desc': 'Enterprise identity providers',
    'sec.redact': 'Personal Info Redaction',
    'sec.redact_desc': 'Selective redaction of sensitive data',
    'sec.role': 'Custom Role Based Control',
    'sec.role_desc': 'Module-level permissions',
    'sec.scale': 'Scalability to Millions',
    'sec.scale_desc': 'Battle-tested infrastructure',
    'sec.impl': 'Implementation Services',
    'sec.impl_desc': 'Professional FDE-led deployment',
    'sec.onprem': 'Enterprise On-prem',
    'sec.onprem_desc': 'Deploy within your infrastructure',
    'sec.uptime': '99.99% Uptime',
    'sec.uptime_desc': 'Guaranteed uptime SLA',
    
    // Integrations
    'int.label': 'Integrations',
    'int.title': 'Seamless Integrations with Your Tech Stack',
    
    // FAQ
    'faq.label': 'FAQ',
    'faq.title': 'Common Questions',
    'faq.q1': 'What is an AI voice agent?',
    'faq.a1': 'An AI voice agent is an autonomous system that can listen, speak, and hold natural phone conversations like a human. It uses speech recognition, large language models, and text-to-speech technology to understand callers and respond intelligently.',
    'faq.q2': 'How do Sondos AI voice agents work?',
    'faq.a2': 'Sondos AI uses proprietary voice AI orchestration with low-latency speech recognition, LLM-powered conversation understanding, and real-time function calling. The platform features ~600ms latency and ultra-realistic voices.',
    'faq.q3': 'How do I create an AI voice agent?',
    'faq.a3': "Sign up for a free account on the dashboard. From there, you can customize and configure your AI voice agent, integrating it seamlessly with your company's data and workflows.",
    'faq.q4': 'Can I connect to my existing phone number?',
    'faq.a4': 'Yes. We support integration with any telephony system through SIP trunking, making it easy to connect your existing phone number without changing infrastructure.',
    'faq.q5': 'Does Sondos AI support Arabic?',
    'faq.a5': 'Yes! Sondos AI is built Arabic-first with native dialect understanding, designed specifically for the Saudi and MENA healthcare market.',
    
    // CTA
    'cta.title': 'Revolutionize Your Call Operations with Sondos AI',
    'cta.subtitle': 'Start building smarter conversations today.',
    'cta.try': 'Try For Free',
    'cta.contact': 'Contact Sales',
    
    // Footer
    'footer.tagline': 'Built to scale, human by design. Subscribe to our newsletter for product updates.',
    'footer.email_ph': 'Enter email',
    'footer.submit': 'Submit',
    'footer.product': 'Product',
    'footer.solutions': 'Solutions',
    'footer.resources': 'Resources',
    'footer.company': 'Company',
    'footer.trust': 'Trust Center',
    'footer.privacy': 'Privacy Policy',
    'footer.terms': 'Terms of Service',
    'footer.copyright': '© 2026 Sondos AI',
  },
  ar: {
    // Navigation
    'nav.product': 'المنتج',
    'nav.pricing': 'الأسعار',
    'nav.for_business': 'للأعمال',
    'nav.for_developers': 'للمطورين',
    'nav.resources': 'الموارد',
    'nav.company': 'الشركة',
    'nav.login': 'دخول',
    'nav.contact_sales': 'تواصل معنا',
    'nav.try_free': 'جرّب مجاناً',
    
    // Product dropdown
    'nav.call_transfer': 'تحويل المكالمات',
    'nav.call_transfer_desc': 'تحويل سلس للمكالمات',
    'nav.book_appointments': 'حجز المواعيد',
    'nav.book_appointments_desc': 'جدولة تلقائية',
    'nav.knowledge_base': 'قاعدة المعرفة',
    'nav.knowledge_base_desc': 'معرفة مدعومة بالذكاء',
    'nav.post_call': 'تحليل ما بعد المكالمة',
    'nav.post_call_desc': 'تحليلات مفصلة',
    'nav.batch_call': 'اتصال جماعي',
    'nav.batch_call_desc': 'حملات اتصال واسعة',
    'nav.verified': 'أرقام موثقة',
    'nav.verified_desc': 'هوية متصل موثوقة',
    
    // Business dropdown
    'nav.healthcare': 'الرعاية الصحية',
    'nav.healthcare_desc': 'المنشآت الطبية',
    'nav.financial': 'الخدمات المالية',
    'nav.financial_desc': 'بنوك ومالية',
    'nav.insurance': 'التأمين',
    'nav.insurance_desc': 'إدارة المطالبات',
    'nav.logistics': 'اللوجستيات',
    'nav.logistics_desc': 'سلسلة الإمداد',
    
    // Hero
    'hero.badge': 'المنصة الأولى لوكيل الصوت الذكي لأتمتة المكالمات',
    'hero.title': 'مركز الاتصال الذكي',
    'hero.title_span': 'من المستقبل',
    'hero.subtitle': 'ابنِ وأطلق وأدِر وكلاء صوتيين بالذكاء الاصطناعي يبدون كالبشر، ينفذون المهام، ويتوسعون بسهولة.',
    'hero.cta_demo': 'جرّب العرض المباشر',
    'hero.cta_sales': 'تواصل مع المبيعات',
    
    // Dashboard
    'dash.dashboard': 'لوحة التحكم',
    'dash.agents': 'الوكلاء',
    'dash.history': 'سجل المكالمات',
    'dash.knowledge': 'قاعدة المعرفة',
    'dash.analytics': 'التحليلات',
    'dash.campaigns': 'الحملات',
    'dash.settings': 'الإعدادات',
    'dash.total_calls': 'المكالمات اليوم',
    'dash.resolution': 'معدل الحل',
    'dash.duration': 'متوسط مدة المكالمة',
    'dash.chart_title': 'حجم المكالمات — آخر 14 يوم',
    
    // Logos
    'logos.trusted': 'موثوق من الشركات الرائدة',
    
    // Banner
    'banner.scale': 'صُمم',
    'banner.scale_span': 'للتوسع.',
    
    // What is
    'what.label': 'نظرة عامة',
    'what.title': 'ما هو سندس AI؟',
    'what.subtitle': 'منصة ذكاء اصطناعي محادثاتي صوتية تعتمد على نماذج اللغة الكبيرة',
    'what.other': 'حل آخر',
    'what.our': 'حلّنا',
    'what.ivr': 'نظام IVR الصوتي',
    'what.ivr_desc': 'يُستخدم أساساً لتوجيه المكالمات عبر قوائم مسبقة التعريف',
    'what.iva': 'وكيل IVA الصوتي',
    'what.iva_desc': 'مدعوم بمعالجة اللغة الطبيعية وتعيين النوايا',
    'what.gen3': 'الجيل الثالث من الصوت الذكي',
    'what.gen3_desc': 'مدعوم بنماذج اللغة الكبيرة',
    'what.feat1': 'محادثات طبيعية شبيهة بالبشر',
    'what.feat2': 'إعداد سريع بأقل تكوين',
    'what.feat3': 'يتعامل مع الحالات غير المتوقعة',
    'what.feat4': 'يدعم المكالمات المعقدة متعددة الأدوار',
    
    // Demo
    'demo.label': 'عرض مباشر',
    'demo.title': 'جرّب عرضنا المباشر',
    'demo.subtitle': 'استقبل مكالمة مباشرة من وكيلنا واكتشف كيف يحوّل المتصل الذكي محادثات العملاء.',
    'demo.step1_title': 'اختر نوع المكالمة',
    'demo.step1_desc': 'اختر من الاستقبال أو حجز المواعيد أو خدمة العملاء',
    'demo.step2_title': 'أدخل معلوماتك',
    'demo.step2_desc': 'أدخل رقم هاتفك وبياناتك',
    'demo.step3_title': 'استقبل المكالمة',
    'demo.step3_desc': 'وكيلنا الذكي سيتصل بك خلال ثوانٍ',
    'demo.form_title': 'اختر نوع المكالمة التي تريد استقبالها',
    'demo.form_subtitle': 'اختر نوع الوكيل ثم أدخل بياناتك',
    'demo.receptionist': 'استقبال',
    'demo.appointment': 'حجز مواعيد',
    'demo.lead': 'تأهيل العملاء',
    'demo.customer': 'خدمة العملاء',
    'demo.debt': 'تحصيل الديون',
    'demo.survey': 'استطلاع',
    'demo.industry': 'القطاع',
    'demo.healthcare': 'الرعاية الصحية',
    'demo.financial': 'الخدمات المالية',
    'demo.insurance': 'التأمين',
    'demo.realestate': 'العقارات',
    'demo.name': 'الاسم',
    'demo.name_ph': 'أدخل الاسم',
    'demo.phone': 'رقم الهاتف',
    'demo.email': 'البريد الإلكتروني',
    'demo.submit': 'استقبل مكالمة',
    
    // Testimonials
    'test.label': 'تأثير مثبت، محادثات حقيقية',
    'test.title': 'تأثير مُثبت، محادثات حقيقية',
    'test.subtitle': 'اكتشف كيف تستخدم الشركات وكلاءنا الصوتيين لتبسيط العمليات والتوسع بسهولة.',
    'test.quote1': 'زدنا كفاءة الجدولة بنسبة 38%، وملأنا طاقة مقدمي الخدمة غير المستغلة، مما سمح لفريقنا بالتركيز على رعاية المرضى.',
    'test.author1': 'د. محمد',
    'test.role1': 'المدير التشغيلي، مجموعة طبية',
    'test.quote2': 'الذكاء الاصطناعي يرد على المكالمات في ثوانٍ، يتعامل مع الدعم العاجل على نطاق واسع، ويخفض تكاليف الدعم بأكثر من 50%.',
    'test.author2': 'سارة الرشيد',
    'test.role2': 'الرئيس التنفيذي، هيلث بريدج',
    'test.quote3': 'الآن نتعامل مع 100% من المكالمات الواردة بمعدل تحويل 30% فقط، ونتوسع بسهولة ونحصّل حوالي 280,000$ شهرياً.',
    'test.author3': 'أحمد خالد',
    'test.role3': 'مدير تقنية المعلومات، ناشيونال ميديكال',
    'test.read_case': 'اقرأ دراسة الحالة',
    
    // Talks Like People
    'talks.title': 'يتحدث مثل',
    'talks.title_span': 'البشر',
    'talks.subtitle': 'لا يمكن تمييزه عن المحادثة البشرية',
    
    // Highlights
    'hl.label': 'المميزات',
    'hl.title': 'وكيل صوتي ذكي بمعيار بشري، جاهز للاستخدام',
    'hl.subtitle': 'تنسيق صوتي ذكي خاص يقدم محادثات هاتفية بجودة بشرية وزمن استجابة منخفض على نطاق واسع',
    'hl.latency_title': 'أقل زمن استجابة',
    'hl.latency_desc': 'تؤكد المعايير المستقلة أن منصتنا رائدة في سرعة الاستجابة. مع زمن استجابة ~600 مللي ثانية، تبقى المحادثات سلسة وطبيعية.',
    'hl.voice_title': 'صوت واقعي للغاية',
    'hl.voice_desc': 'مبني من بيانات أداء حقيقية ومُحسّن عبر التدريب الموجّه بشرياً.',
    'hl.turn_title': 'تبادل الأدوار',
    'hl.turn_desc': 'نموذج تبادل أدوار خاص يعرف متى يتوقف ومتى يستمع.',
    'hl.badge': '~600ms زمن استجابة',
    
    // Features
    'feat.label': 'المميزات',
    'feat.title': 'سهل الاستخدام، منصة وكيل هاتف ذكي قابلة للتخصيص',
    'feat.subtitle': 'تعامل مع كل شيء من الطلبات الروتينية إلى الحالات المعقدة. أطلق في أسابيع لا أشهر.',
    'feat.agentic_title': 'إطار عمل وكيلي قابل للتخصيص بالكامل',
    'feat.agentic_desc': 'صمم تدفقات محادثة موثوقة بإطار عمل وكيلي بالسحب والإفلات، مع حواجز أمان مدمجة وتحكم كامل.',
    'feat.agentic_b1': 'منشئ تدفق بالسحب والإفلات',
    'feat.agentic_b2': 'حواجز أمان مدمجة',
    'feat.agentic_b3': 'تحكم كامل بسلوك الوكيل',
    'feat.func_title': 'استدعاء الوظائف في الوقت الحقيقي',
    'feat.func_desc': 'أضف وظائف مدمجة أو مخصصة في تدفقات المكالمات، مما يمكّن الوكلاء من حجز المواعيد ومعالجة المدفوعات في الوقت الفعلي.',
    'feat.func_b1': 'واجهات حجز المواعيد',
    'feat.func_b2': 'تكامل مع أنظمة CRM و EHR',
    'feat.func_b3': 'مشغلات webhook مخصصة',
    'feat.rag_title': 'RAG المتدفق للمعرفة والمزامنة التلقائية',
    'feat.rag_desc': 'ضمان إجابات دقيقة في الوقت الفعلي في كل مكالمة، مدعومة بقاعدة معرفة تتزامن تلقائياً مع محتوى موقعك.',
    'feat.rag_b1': 'مزامنة تلقائية من المواقع',
    'feat.rag_b2': 'استيعاب PDF والمستندات',
    'feat.rag_b3': 'دعم متعدد اللغات',
    
    // QA
    'qa.label': 'المميزات',
    'qa.title': 'جودة عالية مستمرة في كل مكالمة ذكية، تتحسن باستمرار',
    'qa.test_title': 'اختبار شامل للوكلاء',
    'qa.test_desc': 'اختبر الوكلاء عبر سيناريوهات واقعية قبل الإطلاق، للتحقق من السلوك والدقة والموثوقية.',
    'qa.cont_title': 'ضمان الجودة المستمر',
    'qa.cont_desc': 'راجع المكالمات السابقة لاكتشاف أنماط الفشل والرؤى القابلة للتنفيذ لتحسين أداء الوكيل.',
    'qa.perf_title': 'لوحة تحليلات الأداء',
    'qa.perf_desc': 'صمم مخططات ولوحات مخصصة لتحليل نتائج المكالمات وأداء الوكيل والأثر التجاري.',
    
    // Omni
    'omni.label': 'التكاملات',
    'omni.title': 'تواصل حقيقي متعدد القنوات',
    'omni.voice_title': 'مكالمة صوتية',
    'omni.voice_desc': 'قدّم محادثات هاتفية طبيعية على نطاق واسع.',
    'omni.chat_title': 'محادثة',
    'omni.chat_desc': 'أطلق محادثات مدعومة بالذكاء عبر الويب والتطبيقات.',
    'omni.sms_title': 'رسائل نصية',
    'omni.sms_desc': 'تفاعل مع العملاء عبر رسائل نصية موثوقة.',
    'omni.api_title': 'واجهة برمجة',
    'omni.api_desc': 'ابنِ تجارب تواصل مخصصة عبر واجهة برمجة مرنة.',
    
    // Telephony
    'tel.label': 'المميزات',
    'tel.title': 'بنية اتصالات محسّنة للوصول والموثوقية والنتائج',
    'tel.branded_title': 'عرض هوية المتصل بالعلامة التجارية',
    'tel.branded_desc': 'فعّل ميزة العلامة التجارية للمتصل لمستويات جديدة من ثقة العملاء.',
    'tel.sip_title': 'استخدام SIP Trunking',
    'tel.sip_desc': 'استخدم أرقامك الحالية أو مزودي VOIP. اتصل بأي نظام هاتفي.',
    'tel.batch_title': 'الاتصال الجماعي',
    'tel.batch_desc': 'شغّل حملات اتصال جماعية بدون حدود، مع تتبع تفصيلي للتحويلات.',
    'tel.verified_title': 'أرقام هاتف موثقة',
    'tel.verified_desc': 'ابنِ الثقة بأرقام موثقة تمنع تصنيف مكالماتك كرسائل مزعجة.',
    
    // Security
    'sec.label': 'الامتثال والأمان',
    'sec.title': 'أمان وموثوقية بمستوى المؤسسات',
    'sec.subtitle': 'من حماية البيانات إلى وقت التشغيل، نقدم الأمان المطلوب لتشغيل الصوت الذكي على نطاق إنتاجي.',
    'sec.comp': 'الامتثال والأمان',
    'sec.comp_desc': 'متوافق مع HIPAA و SOC2 Type II و GDPR',
    'sec.sso': 'تسجيل دخول موحد',
    'sec.sso_desc': 'موفري هوية المؤسسات',
    'sec.redact': 'إخفاء البيانات الشخصية',
    'sec.redact_desc': 'إخفاء انتقائي للبيانات الحساسة',
    'sec.role': 'تحكم مخصص بالأدوار',
    'sec.role_desc': 'صلاحيات على مستوى الوحدات',
    'sec.scale': 'قابلية التوسع لملايين المكالمات',
    'sec.scale_desc': 'بنية تحتية مُختبرة',
    'sec.impl': 'خدمات التنفيذ',
    'sec.impl_desc': 'نشر احترافي بقيادة خبراء',
    'sec.onprem': 'نشر محلي للمؤسسات',
    'sec.onprem_desc': 'انشر داخل بنيتك التحتية',
    'sec.uptime': '99.99% وقت تشغيل',
    'sec.uptime_desc': 'اتفاقية وقت تشغيل مضمونة',
    
    // Integrations
    'int.label': 'التكاملات',
    'int.title': 'تكاملات سلسة مع بنيتك التقنية',
    
    // FAQ
    'faq.label': 'الأسئلة الشائعة',
    'faq.title': 'الأسئلة الشائعة',
    'faq.q1': 'ما هو وكيل الصوت الذكي؟',
    'faq.a1': 'وكيل الصوت الذكي هو نظام مستقل يمكنه الاستماع والتحدث وإجراء محادثات هاتفية طبيعية كالبشر. يستخدم التعرف على الكلام ونماذج اللغة الكبيرة وتقنية تحويل النص إلى كلام.',
    'faq.q2': 'كيف يعمل وكلاء سندس AI الصوتيون؟',
    'faq.a2': 'يستخدم سندس AI تنسيقاً صوتياً ذكياً خاصاً مع التعرف على الكلام بزمن استجابة منخفض، وفهم المحادثة المدعوم بنماذج اللغة الكبيرة، واستدعاء الوظائف في الوقت الفعلي.',
    'faq.q3': 'كيف أنشئ وكيل صوتي ذكي؟',
    'faq.a3': 'سجّل حساباً مجانياً في لوحة التحكم. من هناك يمكنك تخصيص وتكوين وكيلك الصوتي الذكي ودمجه بسلاسة مع بيانات شركتك.',
    'faq.q4': 'هل يمكنني الربط برقم هاتفي الحالي؟',
    'faq.a4': 'نعم. ندعم التكامل مع أي نظام هاتفي من خلال SIP trunking، مما يسهل ربط رقمك الحالي دون تغيير البنية التحتية.',
    'faq.q5': 'هل يدعم سندس AI اللغة العربية؟',
    'faq.a5': 'نعم! سندس AI مبني باللغة العربية أولاً مع فهم اللهجات المحلية، مصمم خصيصاً لسوق الرعاية الصحية السعودي والشرق الأوسط.',
    
    // CTA
    'cta.title': 'حوّل عمليات الاتصال مع سندس AI',
    'cta.subtitle': 'ابدأ ببناء محادثات أذكى اليوم.',
    'cta.try': 'جرّب مجاناً',
    'cta.contact': 'تواصل مع المبيعات',
    
    // Footer
    'footer.tagline': 'صُمم للتوسع، بتصميم بشري. اشترك في نشرتنا لتحديثات المنتج.',
    'footer.email_ph': 'أدخل البريد',
    'footer.submit': 'اشتراك',
    'footer.product': 'المنتج',
    'footer.solutions': 'الحلول',
    'footer.resources': 'الموارد',
    'footer.company': 'الشركة',
    'footer.trust': 'مركز الثقة',
    'footer.privacy': 'سياسة الخصوصية',
    'footer.terms': 'شروط الخدمة',
    'footer.copyright': '© 2026 سندس AI',
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Language>('en');

  useEffect(() => {
    const savedLang = localStorage.getItem('sondos-lang') as Language;
    if (savedLang && (savedLang === 'en' || savedLang === 'ar')) {
      setLangState(savedLang);
    }
  }, []);

  const setLang = (newLang: Language) => {
    setLangState(newLang);
    localStorage.setItem('sondos-lang', newLang);
    document.documentElement.setAttribute('dir', newLang === 'ar' ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', newLang);
  };

  const t = (key: string): string => {
    return translations[lang][key] || key;
  };

  useEffect(() => {
    document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', lang);
  }, [lang]);

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
