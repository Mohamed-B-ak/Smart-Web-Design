import { useLanguage } from '@/context/LanguageContext';

const telephonyCards = [
  {
    icon: '🆔',
    title: 'tel.branded_title',
    desc: 'tel.branded_desc',
  },
  {
    icon: '🔗',
    title: 'tel.sip_title',
    desc: 'tel.sip_desc',
  },
  {
    icon: '📋',
    title: 'tel.batch_title',
    desc: 'tel.batch_desc',
  },
  {
    icon: '✅',
    title: 'tel.verified_title',
    desc: 'tel.verified_desc',
  },
];

export default function Telephony() {
  const { t } = useLanguage();

  return (
    <section className="py-24" id="telephony">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="section-label mb-3">{t('tel.label')}</div>
          <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight">
            {t('tel.title')}
          </h2>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-2 gap-4">
          {telephonyCards.map((card, i) => (
            <div
              key={i}
              className="bg-[#12121c] border border-[rgba(255,255,255,0.06)] rounded-xl p-6 flex gap-3.5 transition-all hover:border-[rgba(255,255,255,0.1)]"
            >
              <div className="w-10 h-10 rounded-lg bg-[rgba(124,92,252,0.12)] flex items-center justify-center text-lg flex-shrink-0">
                {card.icon}
              </div>
              <div>
                <h4 className="text-[15px] font-bold mb-1">{t(card.title)}</h4>
                <p className="text-xs text-[#6e6e85] leading-relaxed">
                  {t(card.desc)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
