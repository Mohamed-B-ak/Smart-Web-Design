import { useLanguage } from '@/context/LanguageContext';

const integrations = [
  { name: 'Custom LLM', icon: '🤖' },
  { name: 'Twilio', icon: '📞' },
  { name: 'Vonage', icon: '📱' },
  { name: 'GoHighLevel', icon: '🔧' },
  { name: 'n8n', icon: '⚙️' },
  { name: 'Make', icon: '🔄' },
  { name: 'Salesforce', icon: '📊' },
  { name: 'HubSpot', icon: '📋' },
  { name: 'Cal.com', icon: '📅' },
  { name: 'Zapier', icon: '💾' },
];

export default function Integrations() {
  const { t } = useLanguage();

  return (
    <section className="py-24 bg-[#0f0f17] border-y border-[rgba(255,255,255,0.06)] overflow-hidden" id="integrations">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="section-label mb-3">{t('int.label')}</div>
          <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight">
            {t('int.title')}
          </h2>
        </div>
      </div>

      {/* Carousel */}
      <div className="flex animate-scroll-x w-max" style={{ animationDuration: '28s' }}>
        {[...integrations, ...integrations].map((int, i) => (
          <div
            key={i}
            className="bg-[#12121c] border border-[rgba(255,255,255,0.06)] rounded-full px-5 py-2.5 flex items-center gap-2 text-[13px] font-semibold whitespace-nowrap mx-2 hover:border-[#7c5cfc] hover:bg-[rgba(124,92,252,0.05)] transition-all"
          >
            <span className="w-6 h-6 rounded-md bg-[rgba(124,92,252,0.12)] flex items-center justify-center text-[11px]">
              {int.icon}
            </span>
            {int.name}
          </div>
        ))}
      </div>
    </section>
  );
}
