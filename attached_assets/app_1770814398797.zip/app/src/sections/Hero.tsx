import { useLanguage } from '@/context/LanguageContext';
import { Play, ArrowRight, ArrowLeft } from 'lucide-react';
import AnimatedBackground from './AnimatedBackground';

export default function Hero() {
  const { lang, t } = useLanguage();

  const chartBars = [40, 58, 35, 72, 50, 85, 68, 60, 88, 45, 78, 70, 92, 100];

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center text-center px-6 pt-32 pb-16 overflow-hidden">
      {/* Animated Background */}
      <AnimatedBackground />
      
      {/* Grid Overlay */}
      <div 
        className="absolute inset-0 z-[1] pointer-events-none"
        style={{
          backgroundImage: 'linear-gradient(rgba(255,255,255,.008) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.008) 1px, transparent 1px)',
          backgroundSize: '56px 56px',
          maskImage: 'radial-gradient(ellipse at center, black 30%, transparent 70%)'
        }}
      />

      {/* Content */}
      <div className="relative z-10 max-w-[820px] mx-auto">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-[rgba(124,92,252,0.12)] border border-[rgba(124,92,252,0.25)] rounded-full text-[13px] font-medium text-[#b4a5fd] mb-7 animate-fade-up backdrop-blur-sm">
          <span 
            className="w-2 h-2 rounded-full bg-[#00d68f]"
            style={{ animation: 'dot-pulse 2s infinite' }}
          />
          {t('hero.badge')}
        </div>

        {/* Title */}
        <h1 className="font-['Instrument_Sans',sans-serif] text-[clamp(38px,5.5vw,68px)] font-bold leading-[1.08] tracking-tight mb-5 animate-fade-up animation-delay-100">
          {t('hero.title')}
          <br />
          {lang === 'en' ? 'From The ' : 'من '}
          <span className="gradient-text">{t('hero.title_span')}</span>
        </h1>

        {/* Subtitle */}
        <p className="text-[clamp(16px,1.8vw,19px)] text-[#a1a1b5] max-w-[580px] mx-auto leading-relaxed mb-9 animate-fade-up animation-delay-200">
          {t('hero.subtitle')}
        </p>

        {/* Buttons */}
        <div className="flex items-center justify-center gap-3.5 mb-12 flex-wrap animate-fade-up animation-delay-300">
          <a 
            href="#demo" 
            className="inline-flex items-center gap-2 px-8 py-3.5 text-[15px] font-semibold text-white gradient-bg glow rounded-full hover:-translate-y-0.5 hover:shadow-[0_8px_30px_rgba(124,92,252,0.35)] transition-all"
          >
            <Play className="w-4 h-4 fill-current" />
            {t('hero.cta_demo')}
          </a>
          <a 
            href="#" 
            className="inline-flex items-center gap-2 px-8 py-3.5 text-[15px] font-semibold text-[#f5f5f7] border border-[rgba(255,255,255,0.15)] rounded-full hover:bg-[rgba(255,255,255,0.08)] hover:border-[rgba(255,255,255,0.25)] transition-all backdrop-blur-sm"
          >
            {t('hero.cta_sales')}
            {lang === 'en' ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
          </a>
        </div>
      </div>

      {/* Dashboard Mockup */}
      <div className="relative z-10 max-w-[1060px] w-full mx-auto rounded-3xl overflow-hidden border border-[rgba(124,92,252,0.2)] bg-[rgba(18,18,28,0.8)] backdrop-blur-xl shadow-[0_0_100px_rgba(124,92,252,0.2),0_40px_80px_rgba(0,0,0,0.5)] animate-fade-up animation-delay-500">
        <div className="relative w-full aspect-video bg-gradient-to-br from-[#14141e] to-[#10101c] overflow-hidden">
          {/* Mock Bar */}
          <div className="flex items-center justify-between px-5 py-2.5 bg-[rgba(255,255,255,0.03)] border-b border-[rgba(255,255,255,0.06)]">
            <div className="flex gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ff5f57]" />
              <span className="w-2.5 h-2.5 rounded-full bg-[#ffbd2e]" />
              <span className="w-2.5 h-2.5 rounded-full bg-[#28c840]" />
            </div>
            <div className="text-[11px] text-[#6e6e85] bg-[rgba(255,255,255,0.04)] px-3.5 py-1 rounded-full">
              dashboard.sondos-ai.com
            </div>
            <div className="w-10" />
          </div>

          {/* Mock Body */}
          <div className="grid grid-cols-[200px_1fr] h-[calc(100%-38px)]">
            {/* Sidebar */}
            <div className="bg-[rgba(255,255,255,0.015)] border-r border-[rgba(255,255,255,0.06)] p-3 flex flex-col gap-1">
              {[
                { key: 'dash.dashboard', active: true },
                { key: 'dash.agents', active: false },
                { key: 'dash.history', active: false },
                { key: 'dash.knowledge', active: false },
                { key: 'dash.analytics', active: false },
                { key: 'dash.campaigns', active: false },
                { key: 'dash.settings', active: false },
              ].map((item, i) => (
                <div 
                  key={i}
                  className={`flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs ${
                    item.active 
                      ? 'bg-[rgba(124,92,252,0.15)] text-[#b4a5fd]' 
                      : 'text-[#6e6e85]'
                  }`}
                >
                  <div className={`w-4 h-4 rounded ${item.active ? 'bg-[rgba(124,92,252,0.3)]' : 'bg-[rgba(255,255,255,0.04)]'}`} />
                  {t(item.key)}
                </div>
              ))}
            </div>

            {/* Main */}
            <div className="p-4 flex flex-col gap-3 overflow-hidden">
              {/* Stats */}
              <div className="grid grid-cols-3 gap-2.5">
                {[
                  { label: 'dash.total_calls', val: '2,847', chg: '↑ 24%', positive: true },
                  { label: 'dash.resolution', val: '94.2%', chg: '↑ 3.1%', positive: true },
                  { label: 'dash.duration', val: '2m 34s', chg: '↓ 12s', positive: false },
                ].map((stat, i) => (
                  <div key={i} className="bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.06)] rounded-xl p-3.5">
                    <div className="text-[10px] text-[#6e6e85] mb-1">{t(stat.label)}</div>
                    <div className="font-['Instrument_Sans',sans-serif] text-xl font-bold">{stat.val}</div>
                    <div className={`text-[10px] mt-1 ${stat.positive ? 'text-[#00d68f]' : 'text-[#ff6b6b]'}`}>{stat.chg}</div>
                  </div>
                ))}
              </div>

              {/* Chart */}
              <div className="flex-1 bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.06)] rounded-xl p-3.5 flex flex-col">
                <div className="text-xs font-semibold mb-3">{t('dash.chart_title')}</div>
                <div className="flex items-end gap-1.5 flex-1">
                  {chartBars.map((h, i) => (
                    <div 
                      key={i}
                      className="flex-1 rounded-t bg-gradient-to-t from-[#7c5cfc] via-[#9b8afb] to-[#b4a5fd] opacity-60 hover:opacity-100 transition-all hover:shadow-[0_0_10px_rgba(124,92,252,0.5)]"
                      style={{ height: `${h}%` }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
