import { useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';

const agentTypes = [
  'demo.receptionist',
  'demo.appointment',
  'demo.lead',
  'demo.customer',
  'demo.debt',
  'demo.survey',
];

const industries = [
  'demo.healthcare',
  'demo.financial',
  'demo.insurance',
  'demo.realestate',
];

export default function Demo() {
  const { t } = useLanguage();
  const [selectedAgent, setSelectedAgent] = useState(0);
  const [formData, setFormData] = useState({
    industry: 0,
    name: '',
    phone: '',
    email: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Demo request submitted!');
  };

  return (
    <section className="py-24" id="demo">
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left - Info */}
          <div>
            <div className="section-label mb-3">{t('demo.label')}</div>
            <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight mb-4">
              {t('demo.title')}
            </h2>
            <p className="text-[17px] text-[#a1a1b5] leading-relaxed mb-8">
              {t('demo.subtitle')}
            </p>

            {/* Steps */}
            <div className="flex flex-col gap-5">
              {[
                { num: '1', title: 'demo.step1_title', desc: 'demo.step1_desc' },
                { num: '2', title: 'demo.step2_title', desc: 'demo.step2_desc' },
                { num: '3', title: 'demo.step3_title', desc: 'demo.step3_desc' },
              ].map((step, i) => (
                <div key={i} className="flex gap-3.5 items-start">
                  <div className="w-9 h-9 rounded-full bg-[rgba(124,92,252,0.12)] text-[#9b8afb] flex items-center justify-center font-bold text-[13px] flex-shrink-0">
                    {step.num}
                  </div>
                  <div>
                    <h4 className="text-[15px] font-semibold mb-1">{t(step.title)}</h4>
                    <p className="text-[13px] text-[#6e6e85]">{t(step.desc)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right - Form */}
          <div className="bg-[#12121c] border border-[rgba(255,255,255,0.06)] rounded-2xl p-9 shadow-[0_0_60px_rgba(124,92,252,0.12)]">
            <h3 className="font-['Instrument_Sans',sans-serif] text-xl font-bold mb-1.5">
              {t('demo.form_title')}
            </h3>
            <p className="text-[13px] text-[#6e6e85] mb-6">
              {t('demo.form_subtitle')}
            </p>

            {/* Agent Pills */}
            <div className="flex flex-wrap gap-2 mb-5">
              {agentTypes.map((agent, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedAgent(i)}
                  className={`px-4 py-2 border rounded-full text-[13px] transition-all ${
                    selectedAgent === i
                      ? 'border-[#7c5cfc] text-[#9b8afb] bg-[rgba(124,92,252,0.08)]'
                      : 'border-[rgba(255,255,255,0.1)] text-[#a1a1b5] hover:border-[rgba(255,255,255,0.15)]'
                  }`}
                >
                  {t(agent)}
                </button>
              ))}
            </div>

            <form onSubmit={handleSubmit}>
              {/* Industry */}
              <div className="mb-4">
                <label className="block text-xs font-semibold text-[#a1a1b5] mb-1.5">
                  {t('demo.industry')}
                </label>
                <select 
                  className="w-full px-3.5 py-2.5 bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.06)] rounded-lg text-[#f5f5f7] text-[13px] outline-none focus:border-[#7c5cfc] focus:shadow-[0_0_0_3px_rgba(124,92,252,0.12)] transition-all appearance-none"
                  value={formData.industry}
                  onChange={(e) => setFormData({ ...formData, industry: parseInt(e.target.value) })}
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%236e6e85' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E")`,
                    backgroundRepeat: 'no-repeat',
                    backgroundPosition: 'right 12px center',
                  }}
                >
                  {industries.map((ind, i) => (
                    <option key={i} value={i} className="bg-[#12121c]">{t(ind)}</option>
                  ))}
                </select>
              </div>

              {/* Name & Phone */}
              <div className="grid grid-cols-2 gap-3.5 mb-4">
                <div>
                  <label className="block text-xs font-semibold text-[#a1a1b5] mb-1.5">
                    {t('demo.name')}
                  </label>
                  <input
                    type="text"
                    placeholder={t('demo.name_ph')}
                    className="w-full px-3.5 py-2.5 bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.06)] rounded-lg text-[#f5f5f7] text-[13px] outline-none focus:border-[#7c5cfc] focus:shadow-[0_0_0_3px_rgba(124,92,252,0.12)] transition-all placeholder:text-[#6e6e85]"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#a1a1b5] mb-1.5">
                    {t('demo.phone')}
                  </label>
                  <input
                    type="tel"
                    placeholder="+966 5XX XXX XXXX"
                    className="w-full px-3.5 py-2.5 bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.06)] rounded-lg text-[#f5f5f7] text-[13px] outline-none focus:border-[#7c5cfc] focus:shadow-[0_0_0_3px_rgba(124,92,252,0.12)] transition-all placeholder:text-[#6e6e85]"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  />
                </div>
              </div>

              {/* Email */}
              <div className="mb-4">
                <label className="block text-xs font-semibold text-[#a1a1b5] mb-1.5">
                  {t('demo.email')}
                </label>
                <input
                  type="email"
                  placeholder="name@company.com"
                  className="w-full px-3.5 py-2.5 bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.06)] rounded-lg text-[#f5f5f7] text-[13px] outline-none focus:border-[#7c5cfc] focus:shadow-[0_0_0_3px_rgba(124,92,252,0.12)] transition-all placeholder:text-[#6e6e85]"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>

              {/* Submit */}
              <button
                type="submit"
                className="w-full py-3 gradient-bg text-white text-[14px] font-bold rounded-lg hover:-translate-y-0.5 hover:shadow-[0_6px_25px_rgba(124,92,252,0.25)] transition-all"
              >
                {t('demo.submit')}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
