import { useLanguage } from '@/context/LanguageContext';

export default function Highlights() {
  const { t } = useLanguage();

  const highlights = [
    {
      title: 'hl.latency_title',
      desc: 'hl.latency_desc',
    },
    {
      title: 'hl.voice_title',
      desc: 'hl.voice_desc',
    },
    {
      title: 'hl.turn_title',
      desc: 'hl.turn_desc',
    },
  ];

  return (
    <section className="py-24" id="highlights">
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Content */}
          <div>
            <div className="section-label mb-3">{t('hl.label')}</div>
            <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight mb-4">
              {t('hl.title')}
            </h2>
            <p className="text-[17px] text-[#a1a1b5] leading-relaxed mb-8">
              {t('hl.subtitle')}
            </p>

            <div className="flex flex-col gap-6">
              {highlights.map((hl, i) => (
                <div key={i}>
                  <h4 className="text-[17px] font-bold mb-1">{t(hl.title)}</h4>
                  <p className="text-[14px] text-[#a1a1b5] leading-relaxed">
                    {t(hl.desc)}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Right - Visual */}
          <div className="rounded-2xl bg-gradient-to-br from-[rgba(124,92,252,0.06)] to-[rgba(110,168,254,0.03)] border border-[rgba(255,255,255,0.06)] aspect-square flex items-center justify-center relative overflow-hidden">
            <div className="flex flex-col items-center gap-4">
              {/* Wave Animation */}
              <div className="flex items-center gap-[3px] h-[100px]">
                {Array.from({ length: 12 }).map((_, i) => (
                  <div
                    key={i}
                    className="w-[5px] rounded-full bg-gradient-to-t from-[#7c5cfc] via-[#9b8afb] to-[#6ea8fe] animate-wave"
                    style={{ animationDelay: `${i * 0.1}s` }}
                  />
                ))}
              </div>
              
              {/* Latency Badge */}
              <div className="bg-[rgba(0,214,143,0.1)] text-[#00d68f] text-[13px] font-bold px-5 py-2 rounded-full border border-[rgba(0,214,143,0.2)]">
                {t('hl.badge')}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
