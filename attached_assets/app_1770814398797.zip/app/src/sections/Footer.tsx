import { useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';

export default function Footer() {
  const { t } = useLanguage();
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Subscribed!');
    setEmail('');
  };

  return (
    <footer className="bg-[#0f0f17] border-t border-[rgba(255,255,255,0.06)] pt-20 pb-8">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Top */}
        <div className="grid md:grid-cols-2 lg:grid-cols-[2.2fr_1fr_1fr_1fr_1fr] gap-10 mb-14">
          {/* Brand */}
          <div>
            <a href="#" className="flex items-center gap-2.5 font-bold text-[22px] tracking-tight mb-3.5">
              <div className="w-9 h-9 rounded-lg gradient-bg flex items-center justify-center text-white font-extrabold text-base">
                S
              </div>
              <span>Sondos AI</span>
            </a>
            <p className="text-[13px] text-[#6e6e85] leading-relaxed max-w-[260px] mb-5">
              {t('footer.tagline')}
            </p>
            <form onSubmit={handleSubmit} className="flex gap-2">
              <input
                type="email"
                placeholder={t('footer.email_ph')}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 px-3.5 py-2.5 bg-[rgba(255,255,255,0.04)] border border-[rgba(255,255,255,0.06)] rounded-lg text-[#f5f5f7] text-[13px] outline-none focus:border-[#7c5cfc] transition-all placeholder:text-[#6e6e85]"
              />
              <button
                type="submit"
                className="px-4 py-2.5 gradient-bg text-white text-xs font-bold rounded-lg hover:shadow-[0_4px_15px_rgba(124,92,252,0.25)] transition-all"
              >
                {t('footer.submit')}
              </button>
            </form>
          </div>

          {/* Product */}
          <div>
            <h4 className="text-[11px] font-bold uppercase tracking-widest text-[#a1a1b5] mb-4">
              {t('footer.product')}
            </h4>
            <div className="flex flex-col gap-2.5">
              {['nav.call_transfer', 'nav.book_appointments', 'nav.knowledge_base', 'nav.post_call', 'nav.batch_call', 'nav.pricing'].map((item, i) => (
                <a key={i} href="#" className="text-[13px] text-[#6e6e85] hover:text-[#f5f5f7] transition-colors">
                  {t(item)}
                </a>
              ))}
            </div>
          </div>

          {/* Solutions */}
          <div>
            <h4 className="text-[11px] font-bold uppercase tracking-widest text-[#a1a1b5] mb-4">
              {t('footer.solutions')}
            </h4>
            <div className="flex flex-col gap-2.5">
              {['nav.healthcare', 'nav.financial', 'nav.insurance', 'nav.logistics', 'demo.debt'].map((item, i) => (
                <a key={i} href="#" className="text-[13px] text-[#6e6e85] hover:text-[#f5f5f7] transition-colors">
                  {t(item)}
                </a>
              ))}
            </div>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-[11px] font-bold uppercase tracking-widest text-[#a1a1b5] mb-4">
              {t('footer.resources')}
            </h4>
            <div className="flex flex-col gap-2.5">
              {['Documentation', 'Blog', 'Changelog', 'Customer Stories', 'Status Page'].map((item, i) => (
                <a key={i} href="#" className="text-[13px] text-[#6e6e85] hover:text-[#f5f5f7] transition-colors">
                  {item}
                </a>
              ))}
            </div>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-[11px] font-bold uppercase tracking-widest text-[#a1a1b5] mb-4">
              {t('footer.company')}
            </h4>
            <div className="flex flex-col gap-2.5">
              {['About Us', 'Careers', 'Partners', 'Contact'].map((item, i) => (
                <a key={i} href="#" className="text-[13px] text-[#6e6e85] hover:text-[#f5f5f7] transition-colors">
                  {item}
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-7 border-t border-[rgba(255,255,255,0.06)]">
          <p className="text-xs text-[#6e6e85]">{t('footer.copyright')}</p>
          <div className="flex gap-4">
            {['footer.trust', 'footer.privacy', 'footer.terms'].map((item, i) => (
              <a key={i} href="#" className="text-xs text-[#6e6e85] hover:text-[#f5f5f7] transition-colors">
                {t(item)}
              </a>
            ))}
          </div>
          <div className="flex gap-2.5">
            {['𝕏', 'in', '▶', '⊡'].map((social, i) => (
              <a
                key={i}
                href="#"
                className="w-8 h-8 rounded-full bg-[rgba(255,255,255,0.04)] flex items-center justify-center text-xs text-[#6e6e85] hover:bg-[#7c5cfc] hover:text-white transition-all"
              >
                {social}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
