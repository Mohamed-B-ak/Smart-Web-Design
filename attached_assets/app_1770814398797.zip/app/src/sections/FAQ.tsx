import { useState } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    q: 'faq.q1',
    a: 'faq.a1',
  },
  {
    q: 'faq.q2',
    a: 'faq.a2',
  },
  {
    q: 'faq.q3',
    a: 'faq.a3',
  },
  {
    q: 'faq.q4',
    a: 'faq.a4',
  },
  {
    q: 'faq.q5',
    a: 'faq.a5',
  },
];

export default function FAQ() {
  const { t } = useLanguage();
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggle = (i: number) => {
    setOpenIndex(openIndex === i ? null : i);
  };

  return (
    <section className="py-24" id="faq">
      <div className="max-w-[760px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="section-label mb-3">{t('faq.label')}</div>
          <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight">
            {t('faq.title')}
          </h2>
        </div>

        {/* Accordion */}
        <div className="flex flex-col gap-2">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="bg-[#12121c] border border-[rgba(255,255,255,0.06)] rounded-xl overflow-hidden"
            >
              <button
                onClick={() => toggle(i)}
                className="w-full flex items-center justify-between px-5 py-4 text-left text-[15px] font-semibold text-[#f5f5f7] hover:text-[#9b8afb] transition-colors"
              >
                {t(faq.q)}
                <ChevronDown 
                  className={`w-[18px] h-[18px] text-[#6e6e85] flex-shrink-0 transition-transform ${
                    openIndex === i ? 'rotate-180' : ''
                  }`} 
                />
              </button>
              <div 
                className={`overflow-hidden transition-all ${
                  openIndex === i ? 'max-h-48' : 'max-h-0'
                }`}
              >
                <div className="px-5 pb-4">
                  <p className="text-[14px] text-[#a1a1b5] leading-relaxed">
                    {t(faq.a)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
