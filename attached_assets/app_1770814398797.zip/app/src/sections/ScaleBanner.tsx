import { useLanguage } from '@/context/LanguageContext';

export default function ScaleBanner() {
  const { t } = useLanguage();

  return (
    <section className="py-20 text-center relative overflow-hidden">
      <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(60px,10vw,140px)] font-extrabold tracking-tighter leading-none">
        <span className="text-[rgba(255,255,255,0.03)]">{t('banner.scale')}</span>
        <span className="gradient-text opacity-15"> {t('banner.scale_span')}</span>
      </h2>
    </section>
  );
}
