import { useLanguage } from '@/context/LanguageContext';

const logos = [
  { name: 'Aramco', sym: '▲' },
  { name: 'NEOM', sym: '◆' },
  { name: 'Tamkeen', sym: '●' },
  { name: 'MedGulf', sym: '■' },
  { name: 'Dr. Sulaiman', sym: '★' },
  { name: 'Dallah Health', sym: '◉' },
  { name: 'STC', sym: '▶' },
  { name: 'Mobily', sym: '♦' },
  { name: 'Zain', sym: '◆' },
  { name: 'SAB', sym: '●' },
];

export default function LogoCarousel() {
  const { t } = useLanguage();

  return (
    <section className="py-12 border-y border-[rgba(255,255,255,0.06)] overflow-hidden">
      <div className="text-center text-xs font-semibold uppercase tracking-widest text-[#6e6e85] mb-7">
        {t('logos.trusted')}
      </div>
      <div className="flex animate-scroll-x w-max">
        {[...logos, ...logos].map((logo, i) => (
          <div 
            key={i} 
            className="flex items-center gap-2 px-7 font-['Instrument_Sans',sans-serif] text-[17px] font-bold text-[#6e6e85] whitespace-nowrap opacity-45 hover:opacity-85 transition-opacity"
          >
            <span className="w-6 h-6 rounded-md bg-[rgba(255,255,255,0.05)] flex items-center justify-center text-[11px]">
              {logo.sym}
            </span>
            {logo.name}
          </div>
        ))}
      </div>
    </section>
  );
}
