import { useLanguage } from '@/context/LanguageContext';
import { blogPosts } from '@/data/blog';
import { ArrowRight, ArrowLeft, Clock } from 'lucide-react';

interface BlogListProps {
  onPostClick: (slug: string) => void;
}

export default function BlogList({ onPostClick }: BlogListProps) {
  const { lang } = useLanguage();

  return (
    <section className="py-24 min-h-screen">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="section-label mb-3">Blog</div>
          <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight mb-4">
            {lang === 'en' ? 'Latest Insights' : 'أحدث الرؤى'}
          </h2>
          <p className="text-[17px] text-[#a1a1b5] max-w-[560px] mx-auto leading-relaxed">
            {lang === 'en' 
              ? 'Explore the latest trends and insights in AI voice technology.' 
              : 'استكشف أحدث الاتجاهات والرؤى في تقنية الصوت الذكي.'}
          </p>
        </div>

        {/* Blog Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogPosts.map((post) => (
            <article
              key={post.id}
              onClick={() => onPostClick(post.slug)}
              className="bg-[#12121c] border border-[rgba(255,255,255,0.06)] rounded-xl overflow-hidden cursor-pointer transition-all hover:-translate-y-1 hover:border-[rgba(255,255,255,0.1)] group"
            >
              {/* Image Placeholder */}
              <div className="aspect-video bg-gradient-to-br from-[#14141e] to-[#1a1a2e] flex items-center justify-center relative overflow-hidden">
                <div className="w-16 h-16 rounded-full bg-[rgba(124,92,252,0.12)] flex items-center justify-center text-2xl">
                  📝
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-[#12121c] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>

              {/* Content */}
              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-[#9b8afb] bg-[rgba(124,92,252,0.08)] px-2 py-1 rounded-full">
                    {lang === 'en' ? post.category : post.categoryAr}
                  </span>
                  <span className="flex items-center gap-1 text-[11px] text-[#6e6e85]">
                    <Clock className="w-3 h-3" />
                    {post.readTime}
                  </span>
                </div>

                <h3 className="font-['Instrument_Sans',sans-serif] text-lg font-bold mb-2 line-clamp-2 group-hover:text-[#9b8afb] transition-colors">
                  {lang === 'en' ? post.title : post.titleAr}
                </h3>

                <p className="text-[13px] text-[#a1a1b5] leading-relaxed mb-4 line-clamp-2">
                  {lang === 'en' ? post.excerpt : post.excerptAr}
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full gradient-bg flex items-center justify-center text-xs font-bold text-white">
                      {post.author.charAt(0)}
                    </div>
                    <span className="text-xs text-[#6e6e85]">{post.author}</span>
                  </div>
                  <span className="flex items-center gap-1 text-xs font-semibold text-[#9b8afb] group-hover:underline">
                    {lang === 'en' ? 'Read More' : 'اقرأ المزيد'}
                    {lang === 'en' ? <ArrowRight className="w-3 h-3" /> : <ArrowLeft className="w-3 h-3" />}
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
