import { useLanguage } from '@/context/LanguageContext';

const securityCards = [
  {
    icon: '🛡️',
    title: 'sec.comp',
    desc: 'sec.comp_desc',
  },
  {
    icon: '🔐',
    title: 'sec.sso',
    desc: 'sec.sso_desc',
  },
  {
    icon: '🔒',
    title: 'sec.redact',
    desc: 'sec.redact_desc',
  },
  {
    icon: '👥',
    title: 'sec.role',
    desc: 'sec.role_desc',
  },
  {
    icon: '📈',
    title: 'sec.scale',
    desc: 'sec.scale_desc',
  },
  {
    icon: '🤝',
    title: 'sec.impl',
    desc: 'sec.impl_desc',
  },
  {
    icon: '🏢',
    title: 'sec.onprem',
    desc: 'sec.onprem_desc',
  },
  {
    icon: '⏱️',
    title: 'sec.uptime',
    desc: 'sec.uptime_desc',
  },
];

export default function Security() {
  const { t } = useLanguage();

  return (
    <section className="py-24" id="security">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="section-label mb-3">{t('sec.label')}</div>
          <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight mb-4">
            {t('sec.title')}
          </h2>
          <p className="text-[17px] text-[#a1a1b5] max-w-[560px] mx-auto leading-relaxed">
            {t('sec.subtitle')}
          </p>
        </div>

        {/* Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {securityCards.map((card, i) => (
            <div
              key={i}
              className="bg-[#12121c] border border-[rgba(255,255,255,0.06)] rounded-xl p-5 text-center transition-all hover:-translate-y-0.5 hover:border-[rgba(255,255,255,0.1)]"
            >
              <div className="w-11 h-11 rounded-full bg-[rgba(124,92,252,0.12)] flex items-center justify-center text-lg mx-auto mb-3.5">
                {card.icon}
              </div>
              <h4 className="text-[13px] font-bold mb-1">{t(card.title)}</h4>
              <p className="text-[11px] text-[#6e6e85] leading-relaxed">
                {t(card.desc)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
