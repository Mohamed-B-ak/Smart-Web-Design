import { useState, useEffect } from 'react';
import { useLanguage } from '@/context/LanguageContext';
import { ChevronDown, Menu, X } from 'lucide-react';

export default function Navigation() {
  const { lang, setLang, t } = useLanguage();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [productOpen, setProductOpen] = useState(false);
  const [businessOpen, setBusinessOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleLang = () => {
    setLang(lang === 'en' ? 'ar' : 'en');
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-[rgba(9,9,15,0.85)] backdrop-blur-xl border-b border-[rgba(124,92,252,0.15)] py-2.5'
          : 'bg-transparent py-3.5'
      }`}
    >
      <div className="max-w-[1200px] mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2.5 font-bold text-[22px] tracking-tight group">
          <div className="w-9 h-9 rounded-lg gradient-bg flex items-center justify-center text-white font-extrabold text-base group-hover:shadow-[0_0_20px_rgba(124,92,252,0.5)] transition-shadow">
            S
          </div>
          <span className="group-hover:text-[#b4a5fd] transition-colors">Sondos AI</span>
        </a>

        {/* Desktop Links */}
        <div className="hidden lg:flex items-center gap-1">
          {/* Product Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setProductOpen(true)}
            onMouseLeave={() => setProductOpen(false)}
          >
            <button className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg transition-all">
              {t('nav.product')}
              <ChevronDown className={`w-3 h-3 transition-transform ${productOpen ? 'rotate-180' : ''}`} />
            </button>
            {productOpen && (
              <div className="absolute top-full left-1/2 -translate-x-1/2 pt-2">
                <div className="bg-[rgba(15,15,23,0.95)] backdrop-blur-xl border border-[rgba(124,92,252,0.2)] rounded-xl p-5 min-w-[480px] shadow-[0_20px_60px_rgba(124,92,252,0.2)]">
                  <div className="grid grid-cols-2 gap-1">
                    <a href="#" className="flex gap-3 p-2.5 rounded-lg hover:bg-[rgba(124,92,252,0.1)] items-start transition-all">
                      <div className="w-9 h-9 rounded-lg bg-[rgba(124,92,252,0.15)] flex items-center justify-center flex-shrink-0 text-[15px]">📞</div>
                      <div>
                        <h4 className="text-[13.5px] font-semibold mb-0.5 text-white">{t('nav.call_transfer')}</h4>
                        <p className="text-[11.5px] text-[#6e6e85] leading-tight">{t('nav.call_transfer_desc')}</p>
                      </div>
                    </a>
                    <a href="#" className="flex gap-3 p-2.5 rounded-lg hover:bg-[rgba(124,92,252,0.1)] items-start transition-all">
                      <div className="w-9 h-9 rounded-lg bg-[rgba(124,92,252,0.15)] flex items-center justify-center flex-shrink-0 text-[15px]">📅</div>
                      <div>
                        <h4 className="text-[13.5px] font-semibold mb-0.5 text-white">{t('nav.book_appointments')}</h4>
                        <p className="text-[11.5px] text-[#6e6e85] leading-tight">{t('nav.book_appointments_desc')}</p>
                      </div>
                    </a>
                    <a href="#" className="flex gap-3 p-2.5 rounded-lg hover:bg-[rgba(124,92,252,0.1)] items-start transition-all">
                      <div className="w-9 h-9 rounded-lg bg-[rgba(124,92,252,0.15)] flex items-center justify-center flex-shrink-0 text-[15px]">📚</div>
                      <div>
                        <h4 className="text-[13.5px] font-semibold mb-0.5 text-white">{t('nav.knowledge_base')}</h4>
                        <p className="text-[11.5px] text-[#6e6e85] leading-tight">{t('nav.knowledge_base_desc')}</p>
                      </div>
                    </a>
                    <a href="#" className="flex gap-3 p-2.5 rounded-lg hover:bg-[rgba(124,92,252,0.1)] items-start transition-all">
                      <div className="w-9 h-9 rounded-lg bg-[rgba(124,92,252,0.15)] flex items-center justify-center flex-shrink-0 text-[15px]">📊</div>
                      <div>
                        <h4 className="text-[13.5px] font-semibold mb-0.5 text-white">{t('nav.post_call')}</h4>
                        <p className="text-[11.5px] text-[#6e6e85] leading-tight">{t('nav.post_call_desc')}</p>
                      </div>
                    </a>
                    <a href="#" className="flex gap-3 p-2.5 rounded-lg hover:bg-[rgba(124,92,252,0.1)] items-start transition-all">
                      <div className="w-9 h-9 rounded-lg bg-[rgba(124,92,252,0.15)] flex items-center justify-center flex-shrink-0 text-[15px]">📋</div>
                      <div>
                        <h4 className="text-[13.5px] font-semibold mb-0.5 text-white">{t('nav.batch_call')}</h4>
                        <p className="text-[11.5px] text-[#6e6e85] leading-tight">{t('nav.batch_call_desc')}</p>
                      </div>
                    </a>
                    <a href="#" className="flex gap-3 p-2.5 rounded-lg hover:bg-[rgba(124,92,252,0.1)] items-start transition-all">
                      <div className="w-9 h-9 rounded-lg bg-[rgba(124,92,252,0.15)] flex items-center justify-center flex-shrink-0 text-[15px]">✅</div>
                      <div>
                        <h4 className="text-[13.5px] font-semibold mb-0.5 text-white">{t('nav.verified')}</h4>
                        <p className="text-[11.5px] text-[#6e6e85] leading-tight">{t('nav.verified_desc')}</p>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
            )}
          </div>

          <a href="#" className="px-3.5 py-2 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg transition-all">
            {t('nav.pricing')}
          </a>

          {/* Business Dropdown */}
          <div
            className="relative"
            onMouseEnter={() => setBusinessOpen(true)}
            onMouseLeave={() => setBusinessOpen(false)}
          >
            <button className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg transition-all">
              {t('nav.for_business')}
              <ChevronDown className={`w-3 h-3 transition-transform ${businessOpen ? 'rotate-180' : ''}`} />
            </button>
            {businessOpen && (
              <div className="absolute top-full left-1/2 -translate-x-1/2 pt-2">
                <div className="bg-[rgba(15,15,23,0.95)] backdrop-blur-xl border border-[rgba(124,92,252,0.2)] rounded-xl p-5 min-w-[400px] shadow-[0_20px_60px_rgba(124,92,252,0.2)]">
                  <div className="grid grid-cols-2 gap-1">
                    <a href="#" className="flex gap-3 p-2.5 rounded-lg hover:bg-[rgba(124,92,252,0.1)] items-start transition-all">
                      <div className="w-9 h-9 rounded-lg bg-[rgba(124,92,252,0.15)] flex items-center justify-center flex-shrink-0 text-[15px]">🏥</div>
                      <div>
                        <h4 className="text-[13.5px] font-semibold mb-0.5 text-white">{t('nav.healthcare')}</h4>
                        <p className="text-[11.5px] text-[#6e6e85] leading-tight">{t('nav.healthcare_desc')}</p>
                      </div>
                    </a>
                    <a href="#" className="flex gap-3 p-2.5 rounded-lg hover:bg-[rgba(124,92,252,0.1)] items-start transition-all">
                      <div className="w-9 h-9 rounded-lg bg-[rgba(124,92,252,0.15)] flex items-center justify-center flex-shrink-0 text-[15px]">🏦</div>
                      <div>
                        <h4 className="text-[13.5px] font-semibold mb-0.5 text-white">{t('nav.financial')}</h4>
                        <p className="text-[11.5px] text-[#6e6e85] leading-tight">{t('nav.financial_desc')}</p>
                      </div>
                    </a>
                    <a href="#" className="flex gap-3 p-2.5 rounded-lg hover:bg-[rgba(124,92,252,0.1)] items-start transition-all">
                      <div className="w-9 h-9 rounded-lg bg-[rgba(124,92,252,0.15)] flex items-center justify-center flex-shrink-0 text-[15px]">🛡️</div>
                      <div>
                        <h4 className="text-[13.5px] font-semibold mb-0.5 text-white">{t('nav.insurance')}</h4>
                        <p className="text-[11.5px] text-[#6e6e85] leading-tight">{t('nav.insurance_desc')}</p>
                      </div>
                    </a>
                    <a href="#" className="flex gap-3 p-2.5 rounded-lg hover:bg-[rgba(124,92,252,0.1)] items-start transition-all">
                      <div className="w-9 h-9 rounded-lg bg-[rgba(124,92,252,0.15)] flex items-center justify-center flex-shrink-0 text-[15px]">🚚</div>
                      <div>
                        <h4 className="text-[13.5px] font-semibold mb-0.5 text-white">{t('nav.logistics')}</h4>
                        <p className="text-[11.5px] text-[#6e6e85] leading-tight">{t('nav.logistics_desc')}</p>
                      </div>
                    </a>
                  </div>
                </div>
              </div>
            )}
          </div>

          <a href="#" className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg transition-all">
            {t('nav.for_developers')}
            <ChevronDown className="w-3 h-3" />
          </a>

          <a href="#" className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg transition-all">
            {t('nav.resources')}
            <ChevronDown className="w-3 h-3" />
          </a>

          <a href="#" className="px-3.5 py-2 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg transition-all">
            {t('nav.company')}
          </a>
        </div>

        {/* Actions */}
        <div className="hidden lg:flex items-center gap-2.5">
          <button
            onClick={toggleLang}
            className="w-9 h-9 rounded-full bg-[rgba(124,92,252,0.1)] text-[#b4a5fd] text-xs font-bold flex items-center justify-center border border-[rgba(124,92,252,0.2)] hover:bg-[rgba(124,92,252,0.2)] hover:text-white transition-all"
            title="عربي / English"
          >
            {lang === 'en' ? 'AR' : 'EN'}
          </button>
          <a href="#" className="px-5 py-2 text-sm font-semibold text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-full transition-all">
            {t('nav.login')}
          </a>
          <a href="#" className="px-5 py-2 text-sm font-semibold text-white border border-[rgba(124,92,252,0.3)] hover:bg-[rgba(124,92,252,0.1)] hover:border-[rgba(124,92,252,0.5)] rounded-full transition-all">
            {t('nav.contact_sales')}
          </a>
          <a href="#" className="px-5 py-2 text-sm font-semibold text-white gradient-bg rounded-full hover:-translate-y-0.5 hover:shadow-[0_8px_30px_rgba(124,92,252,0.4)] transition-all">
            {t('nav.try_free')}
          </a>
        </div>

        {/* Mobile Toggle */}
        <button
          className="lg:hidden p-2 text-white"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden absolute top-full left-0 right-0 bg-[rgba(15,15,23,0.98)] backdrop-blur-xl border-b border-[rgba(124,92,252,0.2)] p-4">
          <div className="flex flex-col gap-2">
            <a href="#" className="px-4 py-3 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg">{t('nav.product')}</a>
            <a href="#" className="px-4 py-3 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg">{t('nav.pricing')}</a>
            <a href="#" className="px-4 py-3 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg">{t('nav.for_business')}</a>
            <a href="#" className="px-4 py-3 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg">{t('nav.for_developers')}</a>
            <a href="#" className="px-4 py-3 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg">{t('nav.resources')}</a>
            <a href="#" className="px-4 py-3 text-sm font-medium text-[#a1a1b5] hover:text-white hover:bg-[rgba(124,92,252,0.1)] rounded-lg">{t('nav.company')}</a>
            <div className="flex gap-2 mt-4 pt-4 border-t border-[rgba(124,92,252,0.2)]">
              <button
                onClick={toggleLang}
                className="flex-1 px-4 py-3 text-sm font-semibold text-[#a1a1b5] border border-[rgba(124,92,252,0.3)] rounded-full hover:bg-[rgba(124,92,252,0.1)]"
              >
                {lang === 'en' ? 'العربية' : 'English'}
              </button>
              <a href="#" className="flex-1 px-4 py-3 text-sm font-semibold text-white gradient-bg rounded-full text-center">
                {t('nav.try_free')}
              </a>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
