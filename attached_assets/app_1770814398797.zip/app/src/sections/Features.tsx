import { useLanguage } from '@/context/LanguageContext';

interface FlowNode {
  icon: string;
  text: string;
  color?: string | null;
}

interface Feature {
  title: string;
  desc: string;
  bullets: string[];
  flow: FlowNode[];
}

const features: Feature[] = [
  {
    title: 'feat.agentic_title',
    desc: 'feat.agentic_desc',
    bullets: ['feat.agentic_b1', 'feat.agentic_b2', 'feat.agentic_b3'],
    flow: [
      { icon: '📞', text: 'Incoming Call → Greeting' },
      { icon: '🔍', text: 'Intent Detection → Route' },
      { icon: '📅', text: 'Book Appointment → Confirm' },
      { icon: '✅', text: 'Send Confirmation → End' },
    ],
  },
  {
    title: 'feat.func_title',
    desc: 'feat.func_desc',
    bullets: ['feat.func_b1', 'feat.func_b2', 'feat.func_b3'],
    flow: [
      { icon: '⚡', text: 'function: checkAvailability()', color: '#00d68f' },
      { icon: '🔗', text: 'API: POST /appointments', color: '#4facfe' },
      { icon: '💬', text: 'SMS: Confirmation sent', color: '#ffa940' },
      { icon: '📊', text: 'Analytics: Call logged', color: null },
    ],
  },
  {
    title: 'feat.rag_title',
    desc: 'feat.rag_desc',
    bullets: ['feat.rag_b1', 'feat.rag_b2', 'feat.rag_b3'],
    flow: [
      { icon: '🌐', text: 'Website → Auto Crawl' },
      { icon: '📄', text: 'Documents → Embeddings' },
      { icon: '🧠', text: 'RAG → Smart Retrieval' },
      { icon: '💡', text: 'Accurate Answers' },
    ],
  },
];

export default function Features() {
  const { t } = useLanguage();

  return (
    <section className="py-24 bg-[#0f0f17] border-y border-[rgba(255,255,255,0.06)]" id="features">
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="section-label mb-3">{t('feat.label')}</div>
          <h2 className="font-['Instrument_Sans',sans-serif] text-[clamp(28px,3.5vw,46px)] font-bold leading-tight tracking-tight mb-4">
            {t('feat.title')}
          </h2>
          <p className="text-[17px] text-[#a1a1b5] max-w-[560px] mx-auto leading-relaxed">
            {t('feat.subtitle')}
          </p>
        </div>

        {/* Feature Cards */}
        <div className="flex flex-col gap-5">
          {features.map((feat, i) => (
            <div
              key={i}
              className={`grid lg:grid-cols-2 bg-[#12121c] border border-[rgba(255,255,255,0.06)] rounded-2xl overflow-hidden transition-all hover:border-[rgba(255,255,255,0.1)] ${
                i % 2 === 1 ? 'lg:direction-rtl' : ''
              }`}
            >
              {/* Text */}
              <div className="p-10 flex flex-col justify-center">
                <h3 className="font-['Instrument_Sans',sans-serif] text-[22px] font-bold mb-3 tracking-tight">
                  {t(feat.title)}
                </h3>
                <p className="text-[14px] text-[#a1a1b5] leading-relaxed mb-5">
                  {t(feat.desc)}
                </p>
                <div className="flex flex-col gap-2">
                  {feat.bullets.map((bullet, j) => (
                    <div key={j} className="flex items-center gap-2.5 text-[13px] text-[#a1a1b5]">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#7c5cfc] flex-shrink-0" />
                      {t(bullet)}
                    </div>
                  ))}
                </div>
              </div>

              {/* Visual */}
              <div className="bg-gradient-to-br from-[rgba(124,92,252,0.04)] to-[rgba(124,92,252,0.01)] flex items-center justify-center p-8 min-h-[340px]">
                <div className="flex flex-col gap-0 w-full max-w-[320px]">
                  {feat.flow.map((node, j) => (
                    <div key={j}>
                      <div 
                        className="bg-[rgba(255,255,255,0.03)] border border-[rgba(255,255,255,0.06)] rounded-lg px-4 py-3 flex items-center gap-2.5 text-xs text-[#a1a1b5] hover:border-[#7c5cfc] hover:bg-[rgba(124,92,252,0.04)] transition-all"
                        style={node.color ? { borderColor: node.color } : {}}
                      >
                        <div 
                          className="w-7 h-7 rounded-md bg-[rgba(124,92,252,0.12)] flex items-center justify-center text-[13px] flex-shrink-0"
                          style={node.color ? { background: `${node.color}20` } : {}}
                        >
                          {node.icon}
                        </div>
                        {node.text}
                      </div>
                      {j < feat.flow.length - 1 && (
                        <div className="w-0.5 h-4 bg-[rgba(255,255,255,0.06)] ml-6" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
